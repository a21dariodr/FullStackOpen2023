import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7464bf1a"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7464bf1a"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import AddBlogForm from "/src/components/AddBlogForm.jsx";
import Blog from "/src/components/Blog.jsx?t=1712692146531";
import Notification from "/src/components/Notification.jsx";
import Togglable from "/src/components/Togglable.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState("");
  const togglableRef = useRef();
  useEffect(() => {
    const userJSON = localStorage.getItem("loggedUser");
    if (userJSON) {
      const user2 = JSON.parse(userJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  useEffect(() => {
    if (user) {
      blogService.getAll().then((blogs2) => {
        setBlogs(sortBlogsByLikes(blogs2));
      });
    }
  }, [user]);
  const sortBlogsByLikes = (blogs2) => blogs2.sort((a, b) => b.likes - a.likes);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      console.log("Logging in with", username, password);
      blogService.setToken(user2.token);
      localStorage.setItem("loggedUser", JSON.stringify(user2));
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      console.log("Invalid username or password");
      setMessage("Invalid username or password");
      setTimeout(() => {
        setMessage("");
      }, 6e3);
    }
  };
  const handleLogout = () => {
    localStorage.removeItem("loggedUser");
    setUser(null);
  };
  const createBlog = async (newBlog) => {
    try {
      const createdBlog = await blogService.createBlog({
        title: newBlog.title,
        author: newBlog.author,
        url: newBlog.url
      });
      setBlogs(blogs.concat(createdBlog));
      togglableRef.current.toggleVisibility();
      setMessage(`New blog "${createdBlog.title}" by ${createdBlog.author} added`);
      setTimeout(() => {
        setMessage("");
      }, 6e3);
    } catch (exception) {
      console.log("Error when creating new blog");
    }
  };
  const updateBlog = async (modifiedBlog) => {
    try {
      await blogService.updateBlog(modifiedBlog);
      const filteredBlogs = blogs.filter((blog) => blog.id !== modifiedBlog.id);
      setBlogs(sortBlogsByLikes(filteredBlogs.concat(modifiedBlog)));
    } catch (exception) {
      console.log("Error when updating the blog");
    }
  };
  const deleteBlog = async (blogToDelete) => {
    try {
      await blogService.deleteBlog(blogToDelete);
      const filteredBlogs = blogs.filter((blog) => blog.id !== blogToDelete.id);
      setBlogs(sortBlogsByLikes(filteredBlogs));
    } catch (exception) {
      console.log("Error when deleting the blog");
    }
  };
  const loginForm = () => /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Log in to application" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 94,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message, color: "red" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 95,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: "Username " }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 97,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { "data-testid": "username", type: "text", value: username, onChange: ({
        target
      }) => setUsername(target.value), name: "username" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 98,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 96,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: "Password " }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 103,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { "data-testid": "password", type: "password", value: password, onChange: ({
        target
      }) => setPassword(target.value), name: "password" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 104,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 108,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { "data-testid": "submitButton", type: "submit", children: "Login" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 109,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 93,
    columnNumber: 27
  }, this);
  const blogsList = () => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Blogs" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 112,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      user.name,
      " is logged in  ",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "Logout" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 114,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 113,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 115,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: blogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, updateBlog, deleteBlog }, blog.id, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 117,
      columnNumber: 28
    }, this)) }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 116,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 111,
    columnNumber: 27
  }, this);
  const loggedUserContent = () => /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "Add blog", ref: togglableRef, children: /* @__PURE__ */ jsxDEV(AddBlogForm, { createBlog, togglableRef }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 122,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 121,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message, color: "green" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 124,
      columnNumber: 7
    }, this),
    blogsList()
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 120,
    columnNumber: 35
  }, this);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("h1", { children: "Bloglist app" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 128,
      columnNumber: 7
    }, this),
    user ? loggedUserContent() : loginForm()
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 127,
    columnNumber: 10
  }, this);
};
_s(App, "qp2PNB1xyqY9CDCako70TaheT1U=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUdNLFNBOEJGLFVBOUJFOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZHTixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFFekIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJWixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDYSxVQUFVQyxXQUFXLElBQUlkLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNlLFVBQVVDLFdBQVcsSUFBSWhCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNpQixNQUFNQyxPQUFPLElBQUlsQixTQUFTLElBQUk7QUFFckMsUUFBTSxDQUFDbUIsU0FBU0MsVUFBVSxJQUFJcEIsU0FBUyxFQUFFO0FBRXpDLFFBQU1xQixlQUFlbkIsT0FBTztBQUU1QkQsWUFBVSxNQUFNO0FBQ2QsVUFBTXFCLFdBQVdDLGFBQWFDLFFBQVEsWUFBWTtBQUVsRCxRQUFJRixVQUFVO0FBQ1osWUFBTUwsUUFBT1EsS0FBS0MsTUFBTUosUUFBUTtBQUNoQ0osY0FBUUQsS0FBSTtBQUNaVixrQkFBWW9CLFNBQVNWLE1BQUtXLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwzQixZQUFVLE1BQU07QUFDZCxRQUFJZ0IsTUFBTTtBQUNSVixrQkFBWXNCLE9BQU8sRUFBRUMsS0FBS25CLFlBQVM7QUFDakNDLGlCQUFTbUIsaUJBQWlCcEIsTUFBSyxDQUFDO0FBQUEsTUFDbEMsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLEdBQUcsQ0FBQ00sSUFBSSxDQUFDO0FBRVQsUUFBTWMsbUJBQW1CcEIsWUFBU0EsT0FBTXFCLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRUMsUUFBUUYsRUFBRUUsS0FBSztBQUV4RSxRQUFNQyxjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFFckIsUUFBSTtBQUNGLFlBQU1yQixRQUFPLE1BQU1ULGFBQWErQixNQUFNO0FBQUEsUUFBRTFCO0FBQUFBLFFBQVVFO0FBQUFBLE1BQVMsQ0FBQztBQUU1RHlCLGNBQVFDLElBQUksbUJBQW1CNUIsVUFBVUUsUUFBUTtBQUNqRFIsa0JBQVlvQixTQUFTVixNQUFLVyxLQUFLO0FBQy9CTCxtQkFBYW1CLFFBQVEsY0FBY2pCLEtBQUtrQixVQUFVMUIsS0FBSSxDQUFDO0FBQ3ZEQyxjQUFRRCxLQUFJO0FBQ1pILGtCQUFZLEVBQUU7QUFDZEUsa0JBQVksRUFBRTtBQUFBLElBQ2hCLFNBQVE0QixXQUFXO0FBQ2pCSixjQUFRQyxJQUFJLDhCQUE4QjtBQUUxQ3JCLGlCQUFXLDhCQUE4QjtBQUN6Q3lCLGlCQUFXLE1BQU07QUFDZnpCLG1CQUFXLEVBQUU7QUFBQSxNQUNmLEdBQUcsR0FBSTtBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTTBCLGVBQWVBLE1BQU07QUFDekJ2QixpQkFBYXdCLFdBQVcsWUFBWTtBQUNwQzdCLFlBQVEsSUFBSTtBQUFBLEVBQ2Q7QUFFQSxRQUFNOEIsYUFBYSxPQUFPQyxZQUFZO0FBQ3BDLFFBQUk7QUFDRixZQUFNQyxjQUFjLE1BQU0zQyxZQUFZeUMsV0FBVztBQUFBLFFBQUVHLE9BQU9GLFFBQVFFO0FBQUFBLFFBQU9DLFFBQVFILFFBQVFHO0FBQUFBLFFBQVFDLEtBQUtKLFFBQVFJO0FBQUFBLE1BQUksQ0FBQztBQUNuSHpDLGVBQVNELE1BQU0yQyxPQUFPSixXQUFXLENBQUM7QUFFbEM3QixtQkFBYWtDLFFBQVFDLGlCQUFpQjtBQUV0Q3BDLGlCQUFZLGFBQVk4QixZQUFZQyxLQUFNLFFBQU9ELFlBQVlFLE1BQU8sUUFBTztBQUMzRVAsaUJBQVcsTUFBTTtBQUNmekIsbUJBQVcsRUFBRTtBQUFBLE1BQ2YsR0FBRyxHQUFJO0FBQUEsSUFDVCxTQUFTd0IsV0FBVztBQUNsQkosY0FBUUMsSUFBSSw4QkFBOEI7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0IsYUFBYSxPQUFNQyxpQkFBZ0I7QUFDdkMsUUFBSTtBQUNGLFlBQU1uRCxZQUFZa0QsV0FBV0MsWUFBWTtBQUN6QyxZQUFNQyxnQkFBZ0JoRCxNQUFNaUQsT0FBT0MsVUFBUUEsS0FBS0MsT0FBT0osYUFBYUksRUFBRTtBQUN0RWxELGVBQVNtQixpQkFBaUI0QixjQUFjTCxPQUFPSSxZQUFZLENBQUMsQ0FBQztBQUFBLElBQy9ELFNBQVNkLFdBQVc7QUFDbEJKLGNBQVFDLElBQUksOEJBQThCO0FBQUEsSUFDNUM7QUFBQSxFQUNGO0FBRUEsUUFBTXNCLGFBQWEsT0FBTUMsaUJBQWdCO0FBQ3ZDLFFBQUk7QUFDRixZQUFNekQsWUFBWXdELFdBQVdDLFlBQVk7QUFDekMsWUFBTUwsZ0JBQWdCaEQsTUFBTWlELE9BQU9DLFVBQVFBLEtBQUtDLE9BQU9FLGFBQWFGLEVBQUU7QUFDdEVsRCxlQUFTbUIsaUJBQWlCNEIsYUFBYSxDQUFDO0FBQUEsSUFDMUMsU0FBU2YsV0FBVztBQUNsQkosY0FBUUMsSUFBSSw4QkFBOEI7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFFQSxRQUFNd0IsWUFBWUEsTUFDaEIsdUJBQUMsVUFBSyxVQUFVN0IsYUFDZDtBQUFBLDJCQUFDLFFBQUcscUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUFBLElBQ3pCLHVCQUFDLGdCQUFhLFNBQWtCLE9BQU8sU0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QztBQUFBLElBQzdDLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxVQUFLLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2YsdUJBQUMsV0FBTSxlQUFZLFlBQVcsTUFBSyxRQUFPLE9BQU92QixVQUFVLFVBQVUsQ0FBQztBQUFBLFFBQUVxRDtBQUFBQSxNQUFPLE1BQU1wRCxZQUFZb0QsT0FBT0MsS0FBSyxHQUFHLE1BQUssY0FBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErSDtBQUFBLFNBRmpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFVBQUsseUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFDZix1QkFBQyxXQUFNLGVBQVksWUFBVyxNQUFLLFlBQVcsT0FBT3BELFVBQVUsVUFBVSxDQUFDO0FBQUEsUUFBRW1EO0FBQUFBLE1BQU8sTUFBTWxELFlBQVlrRCxPQUFPQyxLQUFLLEdBQUcsTUFBSyxjQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1JO0FBQUEsU0FGckk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ0gsdUJBQUMsWUFBTyxlQUFZLGdCQUFlLE1BQUssVUFBUyxxQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRDtBQUFBLE9BWnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUdGLFFBQU1DLFlBQVlBLE1BQ2hCLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsU0FBS25EO0FBQUFBLFdBQUtvRDtBQUFBQSxNQUFLO0FBQUEsTUFDUix1QkFBQyxZQUFPLFNBQVN2QixjQUFjLHNCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDO0FBQUEsU0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUNzRDtBQUFBLElBQ3RELHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFDSCx1QkFBQyxTQUNFbkMsZ0JBQU0yRCxJQUFJVCxVQUNULHVCQUFDLFFBQW1CLE1BQVksWUFBd0IsY0FBN0NBLEtBQUtDLElBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0UsQ0FDakYsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVQTtBQUdGLFFBQU1TLG9CQUFvQkEsTUFDeEIsbUNBQ0U7QUFBQSwyQkFBQyxhQUFVLGFBQVksWUFBVyxLQUFLbEQsY0FDckMsaUNBQUMsZUFBWSxZQUF3QixnQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRSxLQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLGdCQUFhLFNBQWtCLE9BQU8sV0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQztBQUFBLElBQzlDK0MsVUFBVTtBQUFBLE9BTGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBR0YsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFFBQUcsNEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQjtBQUFBLElBQ2ZuRCxPQUNHc0Qsa0JBQWtCLElBQ2xCTixVQUFVO0FBQUEsT0FKaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBRUo7QUFBQ3ZELEdBL0lLRCxLQUFHO0FBQUErRCxLQUFIL0Q7QUFpSk4sZUFBZUE7QUFBRyxJQUFBK0Q7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiQWRkQmxvZ0Zvcm0iLCJCbG9nIiwiTm90aWZpY2F0aW9uIiwiVG9nZ2xhYmxlIiwiYmxvZ1NlcnZpY2UiLCJsb2dpblNlcnZpY2UiLCJBcHAiLCJfcyIsImJsb2dzIiwic2V0QmxvZ3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwibWVzc2FnZSIsInNldE1lc3NhZ2UiLCJ0b2dnbGFibGVSZWYiLCJ1c2VySlNPTiIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJzZXRUb2tlbiIsInRva2VuIiwiZ2V0QWxsIiwidGhlbiIsInNvcnRCbG9nc0J5TGlrZXMiLCJzb3J0IiwiYSIsImIiLCJsaWtlcyIsImhhbmRsZUxvZ2luIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImxvZ2luIiwiY29uc29sZSIsImxvZyIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJleGNlcHRpb24iLCJzZXRUaW1lb3V0IiwiaGFuZGxlTG9nb3V0IiwicmVtb3ZlSXRlbSIsImNyZWF0ZUJsb2ciLCJuZXdCbG9nIiwiY3JlYXRlZEJsb2ciLCJ0aXRsZSIsImF1dGhvciIsInVybCIsImNvbmNhdCIsImN1cnJlbnQiLCJ0b2dnbGVWaXNpYmlsaXR5IiwidXBkYXRlQmxvZyIsIm1vZGlmaWVkQmxvZyIsImZpbHRlcmVkQmxvZ3MiLCJmaWx0ZXIiLCJibG9nIiwiaWQiLCJkZWxldGVCbG9nIiwiYmxvZ1RvRGVsZXRlIiwibG9naW5Gb3JtIiwidGFyZ2V0IiwidmFsdWUiLCJibG9nc0xpc3QiLCJuYW1lIiwibWFwIiwibG9nZ2VkVXNlckNvbnRlbnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQWRkQmxvZ0Zvcm0gZnJvbSAnLi9jb21wb25lbnRzL0FkZEJsb2dGb3JtJ1xuaW1wb3J0IEJsb2cgZnJvbSAnLi9jb21wb25lbnRzL0Jsb2cnXG5pbXBvcnQgTm90aWZpY2F0aW9uIGZyb20gJy4vY29tcG9uZW50cy9Ob3RpZmljYXRpb24nXG5pbXBvcnQgVG9nZ2xhYmxlIGZyb20gJy4vY29tcG9uZW50cy9Ub2dnbGFibGUnXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9ibG9ncydcbmltcG9ydCBsb2dpblNlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9sb2dpbidcblxuY29uc3QgQXBwID0gKCkgPT4ge1xuICBjb25zdCBbYmxvZ3MsIHNldEJsb2dzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKVxuXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKCcnKVxuXG4gIGNvbnN0IHRvZ2dsYWJsZVJlZiA9IHVzZVJlZigpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCB1c2VySlNPTiA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsb2dnZWRVc2VyJylcblxuICAgIGlmICh1c2VySlNPTikge1xuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UodXNlckpTT04pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAodXNlcikge1xuICAgICAgYmxvZ1NlcnZpY2UuZ2V0QWxsKCkudGhlbihibG9ncyA9PiB7XG4gICAgICAgIHNldEJsb2dzKHNvcnRCbG9nc0J5TGlrZXMoYmxvZ3MpKVxuICAgICAgfSlcbiAgICB9XG4gIH0sIFt1c2VyXSlcblxuICBjb25zdCBzb3J0QmxvZ3NCeUxpa2VzID0gYmxvZ3MgPT4gYmxvZ3Muc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpXG5cbiAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luU2VydmljZS5sb2dpbih7IHVzZXJuYW1lLCBwYXNzd29yZCB9KVxuXG4gICAgICBjb25zb2xlLmxvZygnTG9nZ2luZyBpbiB3aXRoJywgdXNlcm5hbWUsIHBhc3N3b3JkKVxuICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4odXNlci50b2tlbilcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdsb2dnZWRVc2VyJywgSlNPTi5zdHJpbmdpZnkodXNlcikpXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBzZXRVc2VybmFtZSgnJylcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxuICAgIH0gY2F0Y2goZXhjZXB0aW9uKSB7XG4gICAgICBjb25zb2xlLmxvZygnSW52YWxpZCB1c2VybmFtZSBvciBwYXNzd29yZCcpXG5cbiAgICAgIHNldE1lc3NhZ2UoJ0ludmFsaWQgdXNlcm5hbWUgb3IgcGFzc3dvcmQnKVxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldE1lc3NhZ2UoJycpXG4gICAgICB9LCA2MDAwKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9ICgpID0+IHtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnbG9nZ2VkVXNlcicpXG4gICAgc2V0VXNlcihudWxsKVxuICB9XG5cbiAgY29uc3QgY3JlYXRlQmxvZyA9IGFzeW5jIChuZXdCbG9nKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNyZWF0ZWRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UuY3JlYXRlQmxvZyh7IHRpdGxlOiBuZXdCbG9nLnRpdGxlLCBhdXRob3I6IG5ld0Jsb2cuYXV0aG9yLCB1cmw6IG5ld0Jsb2cudXJsIH0pXG4gICAgICBzZXRCbG9ncyhibG9ncy5jb25jYXQoY3JlYXRlZEJsb2cpKVxuXG4gICAgICB0b2dnbGFibGVSZWYuY3VycmVudC50b2dnbGVWaXNpYmlsaXR5KClcblxuICAgICAgc2V0TWVzc2FnZShgTmV3IGJsb2cgXCIke2NyZWF0ZWRCbG9nLnRpdGxlfVwiIGJ5ICR7Y3JlYXRlZEJsb2cuYXV0aG9yfSBhZGRlZGApXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0TWVzc2FnZSgnJylcbiAgICAgIH0sIDYwMDApXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICBjb25zb2xlLmxvZygnRXJyb3Igd2hlbiBjcmVhdGluZyBuZXcgYmxvZycpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgdXBkYXRlQmxvZyA9IGFzeW5jIG1vZGlmaWVkQmxvZyA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJsb2dTZXJ2aWNlLnVwZGF0ZUJsb2cobW9kaWZpZWRCbG9nKVxuICAgICAgY29uc3QgZmlsdGVyZWRCbG9ncyA9IGJsb2dzLmZpbHRlcihibG9nID0+IGJsb2cuaWQgIT09IG1vZGlmaWVkQmxvZy5pZClcbiAgICAgIHNldEJsb2dzKHNvcnRCbG9nc0J5TGlrZXMoZmlsdGVyZWRCbG9ncy5jb25jYXQobW9kaWZpZWRCbG9nKSkpXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICBjb25zb2xlLmxvZygnRXJyb3Igd2hlbiB1cGRhdGluZyB0aGUgYmxvZycpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgZGVsZXRlQmxvZyA9IGFzeW5jIGJsb2dUb0RlbGV0ZSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJsb2dTZXJ2aWNlLmRlbGV0ZUJsb2coYmxvZ1RvRGVsZXRlKVxuICAgICAgY29uc3QgZmlsdGVyZWRCbG9ncyA9IGJsb2dzLmZpbHRlcihibG9nID0+IGJsb2cuaWQgIT09IGJsb2dUb0RlbGV0ZS5pZClcbiAgICAgIHNldEJsb2dzKHNvcnRCbG9nc0J5TGlrZXMoZmlsdGVyZWRCbG9ncykpXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICBjb25zb2xlLmxvZygnRXJyb3Igd2hlbiBkZWxldGluZyB0aGUgYmxvZycpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgbG9naW5Gb3JtID0gKCkgPT4gKFxuICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVMb2dpbn0+XG4gICAgICA8aDI+TG9nIGluIHRvIGFwcGxpY2F0aW9uPC9oMj5cbiAgICAgIDxOb3RpZmljYXRpb24gbWVzc2FnZT17bWVzc2FnZX0gY29sb3I9eydyZWQnfS8+XG4gICAgICA8ZGl2PlxuICAgICAgICA8c3Bhbj5Vc2VybmFtZSA8L3NwYW4+XG4gICAgICAgIDxpbnB1dCBkYXRhLXRlc3RpZD0ndXNlcm5hbWUnIHR5cGU9J3RleHQnIHZhbHVlPXt1c2VybmFtZX0gb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRVc2VybmFtZSh0YXJnZXQudmFsdWUpfSBuYW1lPSd1c2VybmFtZScvPlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2PlxuICAgICAgICA8c3Bhbj5QYXNzd29yZCA8L3NwYW4+XG4gICAgICAgIDxpbnB1dCBkYXRhLXRlc3RpZD0ncGFzc3dvcmQnIHR5cGU9J3Bhc3N3b3JkJyB2YWx1ZT17cGFzc3dvcmR9IG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0UGFzc3dvcmQodGFyZ2V0LnZhbHVlKX0gbmFtZT0ncGFzc3dvcmQnLz5cbiAgICAgIDwvZGl2PlxuICAgICAgPGJyLz5cbiAgICAgIDxidXR0b24gZGF0YS10ZXN0aWQ9J3N1Ym1pdEJ1dHRvbicgdHlwZT0nc3VibWl0Jz5Mb2dpbjwvYnV0dG9uPlxuICAgIDwvZm9ybT5cbiAgKVxuXG4gIGNvbnN0IGJsb2dzTGlzdCA9ICgpID0+IChcbiAgICA8ZGl2PlxuICAgICAgPGgyPkJsb2dzPC9oMj5cbiAgICAgIDxkaXY+e3VzZXIubmFtZX0gaXMgbG9nZ2VkIGluXG4gICAgICAgICZuYnNwOzxidXR0b24gb25DbGljaz17aGFuZGxlTG9nb3V0fT5Mb2dvdXQ8L2J1dHRvbj48L2Rpdj5cbiAgICAgIDxici8+XG4gICAgICA8ZGl2PlxuICAgICAgICB7YmxvZ3MubWFwKGJsb2cgPT5cbiAgICAgICAgICA8QmxvZyBrZXk9e2Jsb2cuaWR9IGJsb2c9e2Jsb2d9IHVwZGF0ZUJsb2c9e3VwZGF0ZUJsb2d9IGRlbGV0ZUJsb2c9e2RlbGV0ZUJsb2d9Lz5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG5cbiAgY29uc3QgbG9nZ2VkVXNlckNvbnRlbnQgPSAoKSA9PiAoXG4gICAgPD5cbiAgICAgIDxUb2dnbGFibGUgYnV0dG9uTGFiZWw9XCJBZGQgYmxvZ1wiIHJlZj17dG9nZ2xhYmxlUmVmfT5cbiAgICAgICAgPEFkZEJsb2dGb3JtIGNyZWF0ZUJsb2c9e2NyZWF0ZUJsb2d9IHRvZ2dsYWJsZVJlZj17dG9nZ2xhYmxlUmVmfS8+XG4gICAgICA8L1RvZ2dsYWJsZT5cbiAgICAgIDxOb3RpZmljYXRpb24gbWVzc2FnZT17bWVzc2FnZX0gY29sb3I9eydncmVlbid9Lz5cbiAgICAgIHtibG9nc0xpc3QoKX1cbiAgICA8Lz5cbiAgKVxuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxoMT5CbG9nbGlzdCBhcHA8L2gxPlxuICAgICAge3VzZXJcbiAgICAgICAgPyBsb2dnZWRVc2VyQ29udGVudCgpXG4gICAgICAgIDogbG9naW5Gb3JtKClcbiAgICAgIH1cbiAgICA8Lz5cbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBBcHAiXSwiZmlsZSI6Ii9Vc2Vycy9kYXJpby9EZXNrdG9wL0RhcmlvL0luZ2VuaWVyaWEvSW5mb3JtYcyBdGljYSB5IHN1cGVyY29tcHV0YWNpb24gLSBNYXRsYWIgTWF0aGVtYXRpY2EvUmVwb3NpdG9yaW9zIEdpdC9GdWxsU3RhY2tPcGVuL3BhcnQ0L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9BcHAuanN4In0=