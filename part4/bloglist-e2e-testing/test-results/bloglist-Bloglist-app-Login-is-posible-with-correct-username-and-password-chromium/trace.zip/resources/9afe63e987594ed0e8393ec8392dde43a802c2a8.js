import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54f9846b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=54f9846b"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import AddBlogForm from "/src/components/AddBlogForm.jsx";
import Blog from "/src/components/Blog.jsx";
import Notification from "/src/components/Notification.jsx?t=1712258538423";
import Togglable from "/src/components/Togglable.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState("");
  const togglableRef = useRef();
  useEffect(() => {
    const userJSON = localStorage.getItem("loggedUser");
    if (userJSON) {
      const user2 = JSON.parse(userJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  useEffect(() => {
    if (user) {
      blogService.getAll().then((blogs2) => {
        setBlogs(sortBlogsByLikes(blogs2));
      });
    }
  }, [user]);
  const sortBlogsByLikes = (blogs2) => blogs2.sort((a, b) => b.likes - a.likes);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      console.log("Logging in with", username, password);
      blogService.setToken(user2.token);
      localStorage.setItem("loggedUser", JSON.stringify(user2));
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      console.log("Invalid username or password");
      setMessage("Invalid username or password");
      setTimeout(() => {
        setMessage("");
      }, 6e3);
    }
  };
  const handleLogout = () => {
    localStorage.removeItem("loggedUser");
    setUser(null);
  };
  const createBlog = async (newBlog) => {
    try {
      const createdBlog = await blogService.createBlog({
        title: newBlog.title,
        author: newBlog.author,
        url: newBlog.url
      });
      setBlogs(blogs.concat(createdBlog));
      togglableRef.current.toggleVisibility();
      setMessage(`New blog "${createdBlog.title}" by ${createdBlog.author} added`);
      setTimeout(() => {
        setMessage("");
      }, 6e3);
    } catch (exception) {
      console.log("Error when creating new blog");
    }
  };
  const updateBlog = async (modifiedBlog) => {
    try {
      const updatedBlog = await blogService.updateBlog(modifiedBlog);
      const filteredBlogs = blogs.filter((blog) => blog.id !== modifiedBlog.id);
      setBlogs(sortBlogsByLikes(filteredBlogs.concat(modifiedBlog)));
    } catch (exception) {
      console.log("Error when updating the blog");
    }
  };
  const deleteBlog = async (blogToDelete) => {
    try {
      await blogService.deleteBlog(blogToDelete);
      const filteredBlogs = blogs.filter((blog) => blog.id !== blogToDelete.id);
      setBlogs(sortBlogsByLikes(filteredBlogs));
    } catch (exception) {
      console.log("Error when deleting the blog");
    }
  };
  const loginForm = () => /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Log in to application" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 94,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message, color: "red" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 95,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: "Username " }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 97,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { "data-testid": "username", type: "text", value: username, onChange: ({
        target
      }) => setUsername(target.value), name: "username" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 98,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 96,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: "Password " }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 103,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { "data-testid": "password", type: "password", value: password, onChange: ({
        target
      }) => setPassword(target.value), name: "password" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 104,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 108,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { "data-testid": "submitButton", type: "submit", children: "Login" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 109,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 93,
    columnNumber: 27
  }, this);
  const blogsList = () => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Blogs" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 112,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      user.name,
      " is logged in  ",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "Logout" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 114,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 113,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 115,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: blogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, updateBlog, deleteBlog }, blog.id, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 117,
      columnNumber: 28
    }, this)) }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 116,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 111,
    columnNumber: 27
  }, this);
  const loggedUserContent = () => /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "Add blog", ref: togglableRef, children: /* @__PURE__ */ jsxDEV(AddBlogForm, { createBlog, togglableRef }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 122,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 121,
      columnNumber: 7
    }, this),
    blogsList()
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 120,
    columnNumber: 35
  }, this);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("h1", { children: "Bloglist app" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 127,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message, color: "green" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 128,
      columnNumber: 7
    }, this),
    user ? loggedUserContent() : loginForm()
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 126,
    columnNumber: 10
  }, this);
};
_s(App, "qp2PNB1xyqY9CDCako70TaheT1U=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUdNLFNBOEJGLFVBOUJFOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZHTixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFFekIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJWixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDYSxVQUFVQyxXQUFXLElBQUlkLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNlLFVBQVVDLFdBQVcsSUFBSWhCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNpQixNQUFNQyxPQUFPLElBQUlsQixTQUFTLElBQUk7QUFFckMsUUFBTSxDQUFDbUIsU0FBU0MsVUFBVSxJQUFJcEIsU0FBUyxFQUFFO0FBRXpDLFFBQU1xQixlQUFlbkIsT0FBTztBQUU1QkQsWUFBVSxNQUFNO0FBQ2QsVUFBTXFCLFdBQVdDLGFBQWFDLFFBQVEsWUFBWTtBQUVsRCxRQUFJRixVQUFVO0FBQ1osWUFBTUwsUUFBT1EsS0FBS0MsTUFBTUosUUFBUTtBQUNoQ0osY0FBUUQsS0FBSTtBQUNaVixrQkFBWW9CLFNBQVNWLE1BQUtXLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwzQixZQUFVLE1BQU07QUFDZCxRQUFJZ0IsTUFBTTtBQUNSVixrQkFBWXNCLE9BQU8sRUFBRUMsS0FBS25CLFlBQVM7QUFDakNDLGlCQUFTbUIsaUJBQWlCcEIsTUFBSyxDQUFDO0FBQUEsTUFDbEMsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLEdBQUcsQ0FBQ00sSUFBSSxDQUFDO0FBRVQsUUFBTWMsbUJBQW1CcEIsWUFBU0EsT0FBTXFCLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRUMsUUFBUUYsRUFBRUUsS0FBSztBQUV4RSxRQUFNQyxjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFFckIsUUFBSTtBQUNGLFlBQU1yQixRQUFPLE1BQU1ULGFBQWErQixNQUFNO0FBQUEsUUFBRTFCO0FBQUFBLFFBQVVFO0FBQUFBLE1BQVMsQ0FBQztBQUU1RHlCLGNBQVFDLElBQUksbUJBQW1CNUIsVUFBVUUsUUFBUTtBQUNqRFIsa0JBQVlvQixTQUFTVixNQUFLVyxLQUFLO0FBQy9CTCxtQkFBYW1CLFFBQVEsY0FBY2pCLEtBQUtrQixVQUFVMUIsS0FBSSxDQUFDO0FBQ3ZEQyxjQUFRRCxLQUFJO0FBQ1pILGtCQUFZLEVBQUU7QUFDZEUsa0JBQVksRUFBRTtBQUFBLElBQ2hCLFNBQVE0QixXQUFXO0FBQ2pCSixjQUFRQyxJQUFJLDhCQUE4QjtBQUUxQ3JCLGlCQUFXLDhCQUE4QjtBQUN6Q3lCLGlCQUFXLE1BQU07QUFDZnpCLG1CQUFXLEVBQUU7QUFBQSxNQUNmLEdBQUcsR0FBSTtBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTTBCLGVBQWVBLE1BQU07QUFDekJ2QixpQkFBYXdCLFdBQVcsWUFBWTtBQUNwQzdCLFlBQVEsSUFBSTtBQUFBLEVBQ2Q7QUFFQSxRQUFNOEIsYUFBYSxPQUFPQyxZQUFZO0FBQ3BDLFFBQUk7QUFDRixZQUFNQyxjQUFjLE1BQU0zQyxZQUFZeUMsV0FBVztBQUFBLFFBQUVHLE9BQU9GLFFBQVFFO0FBQUFBLFFBQU9DLFFBQVFILFFBQVFHO0FBQUFBLFFBQVFDLEtBQUtKLFFBQVFJO0FBQUFBLE1BQUksQ0FBQztBQUNuSHpDLGVBQVNELE1BQU0yQyxPQUFPSixXQUFXLENBQUM7QUFFbEM3QixtQkFBYWtDLFFBQVFDLGlCQUFpQjtBQUV0Q3BDLGlCQUFZLGFBQVk4QixZQUFZQyxLQUFNLFFBQU9ELFlBQVlFLE1BQU8sUUFBTztBQUMzRVAsaUJBQVcsTUFBTTtBQUNmekIsbUJBQVcsRUFBRTtBQUFBLE1BQ2YsR0FBRyxHQUFJO0FBQUEsSUFDVCxTQUFTd0IsV0FBVztBQUNsQkosY0FBUUMsSUFBSSw4QkFBOEI7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0IsYUFBYSxPQUFNQyxpQkFBZ0I7QUFDdkMsUUFBSTtBQUNGLFlBQU1DLGNBQWMsTUFBTXBELFlBQVlrRCxXQUFXQyxZQUFZO0FBQzdELFlBQU1FLGdCQUFnQmpELE1BQU1rRCxPQUFPQyxVQUFRQSxLQUFLQyxPQUFPTCxhQUFhSyxFQUFFO0FBQ3RFbkQsZUFBU21CLGlCQUFpQjZCLGNBQWNOLE9BQU9JLFlBQVksQ0FBQyxDQUFDO0FBQUEsSUFDL0QsU0FBU2QsV0FBVztBQUNsQkosY0FBUUMsSUFBSSw4QkFBOEI7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFFQSxRQUFNdUIsYUFBYSxPQUFNQyxpQkFBZ0I7QUFDdkMsUUFBSTtBQUNGLFlBQU0xRCxZQUFZeUQsV0FBV0MsWUFBWTtBQUN6QyxZQUFNTCxnQkFBZ0JqRCxNQUFNa0QsT0FBT0MsVUFBUUEsS0FBS0MsT0FBT0UsYUFBYUYsRUFBRTtBQUN0RW5ELGVBQVNtQixpQkFBaUI2QixhQUFhLENBQUM7QUFBQSxJQUMxQyxTQUFTaEIsV0FBVztBQUNsQkosY0FBUUMsSUFBSSw4QkFBOEI7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFFQSxRQUFNeUIsWUFBWUEsTUFDaEIsdUJBQUMsVUFBSyxVQUFVOUIsYUFDZDtBQUFBLDJCQUFDLFFBQUcscUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUFBLElBQ3pCLHVCQUFDLGdCQUFhLFNBQWtCLE9BQU8sU0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QztBQUFBLElBQzdDLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxVQUFLLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2YsdUJBQUMsV0FBTSxlQUFZLFlBQVcsTUFBSyxRQUFPLE9BQU92QixVQUFVLFVBQVUsQ0FBQztBQUFBLFFBQUVzRDtBQUFBQSxNQUFPLE1BQU1yRCxZQUFZcUQsT0FBT0MsS0FBSyxHQUFHLE1BQUssY0FBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErSDtBQUFBLFNBRmpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFVBQUsseUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFDZix1QkFBQyxXQUFNLGVBQVksWUFBVyxNQUFLLFlBQVcsT0FBT3JELFVBQVUsVUFBVSxDQUFDO0FBQUEsUUFBRW9EO0FBQUFBLE1BQU8sTUFBTW5ELFlBQVltRCxPQUFPQyxLQUFLLEdBQUcsTUFBSyxjQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1JO0FBQUEsU0FGckk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ0gsdUJBQUMsWUFBTyxlQUFZLGdCQUFlLE1BQUssVUFBUyxxQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRDtBQUFBLE9BWnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUdGLFFBQU1DLFlBQVlBLE1BQ2hCLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsU0FBS3BEO0FBQUFBLFdBQUtxRDtBQUFBQSxNQUFLO0FBQUEsTUFDUix1QkFBQyxZQUFPLFNBQVN4QixjQUFjLHNCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDO0FBQUEsU0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUNzRDtBQUFBLElBQ3RELHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFDSCx1QkFBQyxTQUNFbkMsZ0JBQU00RCxJQUFJVCxVQUNULHVCQUFDLFFBQW1CLE1BQVksWUFBd0IsY0FBN0NBLEtBQUtDLElBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0UsQ0FDakYsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVQTtBQUdGLFFBQU1TLG9CQUFvQkEsTUFDeEIsbUNBQ0U7QUFBQSwyQkFBQyxhQUFVLGFBQVksWUFBVyxLQUFLbkQsY0FDckMsaUNBQUMsZUFBWSxZQUF3QixnQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRSxLQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNDZ0QsVUFBVTtBQUFBLE9BSmI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBO0FBR0YsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFFBQUcsNEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQjtBQUFBLElBQ2hCLHVCQUFDLGdCQUFhLFNBQWtCLE9BQU8sV0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQztBQUFBLElBQzlDcEQsT0FDR3VELGtCQUFrQixJQUNsQk4sVUFBVTtBQUFBLE9BTGhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FPQTtBQUVKO0FBQUN4RCxHQS9JS0QsS0FBRztBQUFBZ0UsS0FBSGhFO0FBaUpOLGVBQWVBO0FBQUcsSUFBQWdFO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZVJlZiIsIkFkZEJsb2dGb3JtIiwiQmxvZyIsIk5vdGlmaWNhdGlvbiIsIlRvZ2dsYWJsZSIsImJsb2dTZXJ2aWNlIiwibG9naW5TZXJ2aWNlIiwiQXBwIiwiX3MiLCJibG9ncyIsInNldEJsb2dzIiwidXNlcm5hbWUiLCJzZXRVc2VybmFtZSIsInBhc3N3b3JkIiwic2V0UGFzc3dvcmQiLCJ1c2VyIiwic2V0VXNlciIsIm1lc3NhZ2UiLCJzZXRNZXNzYWdlIiwidG9nZ2xhYmxlUmVmIiwidXNlckpTT04iLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiSlNPTiIsInBhcnNlIiwic2V0VG9rZW4iLCJ0b2tlbiIsImdldEFsbCIsInRoZW4iLCJzb3J0QmxvZ3NCeUxpa2VzIiwic29ydCIsImEiLCJiIiwibGlrZXMiLCJoYW5kbGVMb2dpbiIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJsb2dpbiIsImNvbnNvbGUiLCJsb2ciLCJzZXRJdGVtIiwic3RyaW5naWZ5IiwiZXhjZXB0aW9uIiwic2V0VGltZW91dCIsImhhbmRsZUxvZ291dCIsInJlbW92ZUl0ZW0iLCJjcmVhdGVCbG9nIiwibmV3QmxvZyIsImNyZWF0ZWRCbG9nIiwidGl0bGUiLCJhdXRob3IiLCJ1cmwiLCJjb25jYXQiLCJjdXJyZW50IiwidG9nZ2xlVmlzaWJpbGl0eSIsInVwZGF0ZUJsb2ciLCJtb2RpZmllZEJsb2ciLCJ1cGRhdGVkQmxvZyIsImZpbHRlcmVkQmxvZ3MiLCJmaWx0ZXIiLCJibG9nIiwiaWQiLCJkZWxldGVCbG9nIiwiYmxvZ1RvRGVsZXRlIiwibG9naW5Gb3JtIiwidGFyZ2V0IiwidmFsdWUiLCJibG9nc0xpc3QiLCJuYW1lIiwibWFwIiwibG9nZ2VkVXNlckNvbnRlbnQiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCwgdXNlUmVmIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgQWRkQmxvZ0Zvcm0gZnJvbSAnLi9jb21wb25lbnRzL0FkZEJsb2dGb3JtJ1xuaW1wb3J0IEJsb2cgZnJvbSAnLi9jb21wb25lbnRzL0Jsb2cnXG5pbXBvcnQgTm90aWZpY2F0aW9uIGZyb20gJy4vY29tcG9uZW50cy9Ob3RpZmljYXRpb24nXG5pbXBvcnQgVG9nZ2xhYmxlIGZyb20gJy4vY29tcG9uZW50cy9Ub2dnbGFibGUnXG5pbXBvcnQgYmxvZ1NlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9ibG9ncydcbmltcG9ydCBsb2dpblNlcnZpY2UgZnJvbSAnLi9zZXJ2aWNlcy9sb2dpbidcblxuY29uc3QgQXBwID0gKCkgPT4ge1xuICBjb25zdCBbYmxvZ3MsIHNldEJsb2dzXSA9IHVzZVN0YXRlKFtdKVxuICBjb25zdCBbdXNlcm5hbWUsIHNldFVzZXJuYW1lXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbcGFzc3dvcmQsIHNldFBhc3N3b3JkXSA9IHVzZVN0YXRlKCcnKVxuICBjb25zdCBbdXNlciwgc2V0VXNlcl0gPSB1c2VTdGF0ZShudWxsKVxuXG4gIGNvbnN0IFttZXNzYWdlLCBzZXRNZXNzYWdlXSA9IHVzZVN0YXRlKCcnKVxuXG4gIGNvbnN0IHRvZ2dsYWJsZVJlZiA9IHVzZVJlZigpXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBjb25zdCB1c2VySlNPTiA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsb2dnZWRVc2VyJylcblxuICAgIGlmICh1c2VySlNPTikge1xuICAgICAgY29uc3QgdXNlciA9IEpTT04ucGFyc2UodXNlckpTT04pXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgIH1cbiAgfSwgW10pXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAodXNlcikge1xuICAgICAgYmxvZ1NlcnZpY2UuZ2V0QWxsKCkudGhlbihibG9ncyA9PiB7XG4gICAgICAgIHNldEJsb2dzKHNvcnRCbG9nc0J5TGlrZXMoYmxvZ3MpKVxuICAgICAgfSlcbiAgICB9XG4gIH0sIFt1c2VyXSlcblxuICBjb25zdCBzb3J0QmxvZ3NCeUxpa2VzID0gYmxvZ3MgPT4gYmxvZ3Muc29ydCgoYSwgYikgPT4gYi5saWtlcyAtIGEubGlrZXMpXG5cbiAgY29uc3QgaGFuZGxlTG9naW4gPSBhc3luYyAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgdXNlciA9IGF3YWl0IGxvZ2luU2VydmljZS5sb2dpbih7IHVzZXJuYW1lLCBwYXNzd29yZCB9KVxuXG4gICAgICBjb25zb2xlLmxvZygnTG9nZ2luZyBpbiB3aXRoJywgdXNlcm5hbWUsIHBhc3N3b3JkKVxuICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4odXNlci50b2tlbilcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKCdsb2dnZWRVc2VyJywgSlNPTi5zdHJpbmdpZnkodXNlcikpXG4gICAgICBzZXRVc2VyKHVzZXIpXG4gICAgICBzZXRVc2VybmFtZSgnJylcbiAgICAgIHNldFBhc3N3b3JkKCcnKVxuICAgIH0gY2F0Y2goZXhjZXB0aW9uKSB7XG4gICAgICBjb25zb2xlLmxvZygnSW52YWxpZCB1c2VybmFtZSBvciBwYXNzd29yZCcpXG5cbiAgICAgIHNldE1lc3NhZ2UoJ0ludmFsaWQgdXNlcm5hbWUgb3IgcGFzc3dvcmQnKVxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldE1lc3NhZ2UoJycpXG4gICAgICB9LCA2MDAwKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGhhbmRsZUxvZ291dCA9ICgpID0+IHtcbiAgICBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbSgnbG9nZ2VkVXNlcicpXG4gICAgc2V0VXNlcihudWxsKVxuICB9XG5cbiAgY29uc3QgY3JlYXRlQmxvZyA9IGFzeW5jIChuZXdCbG9nKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGNyZWF0ZWRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UuY3JlYXRlQmxvZyh7IHRpdGxlOiBuZXdCbG9nLnRpdGxlLCBhdXRob3I6IG5ld0Jsb2cuYXV0aG9yLCB1cmw6IG5ld0Jsb2cudXJsIH0pXG4gICAgICBzZXRCbG9ncyhibG9ncy5jb25jYXQoY3JlYXRlZEJsb2cpKVxuXG4gICAgICB0b2dnbGFibGVSZWYuY3VycmVudC50b2dnbGVWaXNpYmlsaXR5KClcblxuICAgICAgc2V0TWVzc2FnZShgTmV3IGJsb2cgXCIke2NyZWF0ZWRCbG9nLnRpdGxlfVwiIGJ5ICR7Y3JlYXRlZEJsb2cuYXV0aG9yfSBhZGRlZGApXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0TWVzc2FnZSgnJylcbiAgICAgIH0sIDYwMDApXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICBjb25zb2xlLmxvZygnRXJyb3Igd2hlbiBjcmVhdGluZyBuZXcgYmxvZycpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgdXBkYXRlQmxvZyA9IGFzeW5jIG1vZGlmaWVkQmxvZyA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVwZGF0ZWRCbG9nID0gYXdhaXQgYmxvZ1NlcnZpY2UudXBkYXRlQmxvZyhtb2RpZmllZEJsb2cpXG4gICAgICBjb25zdCBmaWx0ZXJlZEJsb2dzID0gYmxvZ3MuZmlsdGVyKGJsb2cgPT4gYmxvZy5pZCAhPT0gbW9kaWZpZWRCbG9nLmlkKVxuICAgICAgc2V0QmxvZ3Moc29ydEJsb2dzQnlMaWtlcyhmaWx0ZXJlZEJsb2dzLmNvbmNhdChtb2RpZmllZEJsb2cpKSlcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIGNvbnNvbGUubG9nKCdFcnJvciB3aGVuIHVwZGF0aW5nIHRoZSBibG9nJylcbiAgICB9XG4gIH1cblxuICBjb25zdCBkZWxldGVCbG9nID0gYXN5bmMgYmxvZ1RvRGVsZXRlID0+IHtcbiAgICB0cnkge1xuICAgICAgYXdhaXQgYmxvZ1NlcnZpY2UuZGVsZXRlQmxvZyhibG9nVG9EZWxldGUpXG4gICAgICBjb25zdCBmaWx0ZXJlZEJsb2dzID0gYmxvZ3MuZmlsdGVyKGJsb2cgPT4gYmxvZy5pZCAhPT0gYmxvZ1RvRGVsZXRlLmlkKVxuICAgICAgc2V0QmxvZ3Moc29ydEJsb2dzQnlMaWtlcyhmaWx0ZXJlZEJsb2dzKSlcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIGNvbnNvbGUubG9nKCdFcnJvciB3aGVuIGRlbGV0aW5nIHRoZSBibG9nJylcbiAgICB9XG4gIH1cblxuICBjb25zdCBsb2dpbkZvcm0gPSAoKSA9PiAoXG4gICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZUxvZ2lufT5cbiAgICAgIDxoMj5Mb2cgaW4gdG8gYXBwbGljYXRpb248L2gyPlxuICAgICAgPE5vdGlmaWNhdGlvbiBtZXNzYWdlPXttZXNzYWdlfSBjb2xvcj17J3JlZCd9Lz5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxzcGFuPlVzZXJuYW1lIDwvc3Bhbj5cbiAgICAgICAgPGlucHV0IGRhdGEtdGVzdGlkPSd1c2VybmFtZScgdHlwZT0ndGV4dCcgdmFsdWU9e3VzZXJuYW1lfSBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFVzZXJuYW1lKHRhcmdldC52YWx1ZSl9IG5hbWU9J3VzZXJuYW1lJy8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxzcGFuPlBhc3N3b3JkIDwvc3Bhbj5cbiAgICAgICAgPGlucHV0IGRhdGEtdGVzdGlkPSdwYXNzd29yZCcgdHlwZT0ncGFzc3dvcmQnIHZhbHVlPXtwYXNzd29yZH0gb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRQYXNzd29yZCh0YXJnZXQudmFsdWUpfSBuYW1lPSdwYXNzd29yZCcvPlxuICAgICAgPC9kaXY+XG4gICAgICA8YnIvPlxuICAgICAgPGJ1dHRvbiBkYXRhLXRlc3RpZD0nc3VibWl0QnV0dG9uJyB0eXBlPSdzdWJtaXQnPkxvZ2luPC9idXR0b24+XG4gICAgPC9mb3JtPlxuICApXG5cbiAgY29uc3QgYmxvZ3NMaXN0ID0gKCkgPT4gKFxuICAgIDxkaXY+XG4gICAgICA8aDI+QmxvZ3M8L2gyPlxuICAgICAgPGRpdj57dXNlci5uYW1lfSBpcyBsb2dnZWQgaW5cbiAgICAgICAgJm5ic3A7PGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9PkxvZ291dDwvYnV0dG9uPjwvZGl2PlxuICAgICAgPGJyLz5cbiAgICAgIDxkaXY+XG4gICAgICAgIHtibG9ncy5tYXAoYmxvZyA9PlxuICAgICAgICAgIDxCbG9nIGtleT17YmxvZy5pZH0gYmxvZz17YmxvZ30gdXBkYXRlQmxvZz17dXBkYXRlQmxvZ30gZGVsZXRlQmxvZz17ZGVsZXRlQmxvZ30vPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcblxuICBjb25zdCBsb2dnZWRVc2VyQ29udGVudCA9ICgpID0+IChcbiAgICA8PlxuICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD1cIkFkZCBibG9nXCIgcmVmPXt0b2dnbGFibGVSZWZ9PlxuICAgICAgICA8QWRkQmxvZ0Zvcm0gY3JlYXRlQmxvZz17Y3JlYXRlQmxvZ30gdG9nZ2xhYmxlUmVmPXt0b2dnbGFibGVSZWZ9Lz5cbiAgICAgIDwvVG9nZ2xhYmxlPlxuICAgICAge2Jsb2dzTGlzdCgpfVxuICAgIDwvPlxuICApXG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGgxPkJsb2dsaXN0IGFwcDwvaDE+XG4gICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e21lc3NhZ2V9IGNvbG9yPXsnZ3JlZW4nfS8+XG4gICAgICB7dXNlclxuICAgICAgICA/IGxvZ2dlZFVzZXJDb250ZW50KClcbiAgICAgICAgOiBsb2dpbkZvcm0oKVxuICAgICAgfVxuICAgIDwvPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcCJdLCJmaWxlIjoiL1VzZXJzL2RhcmlvL0Rlc2t0b3AvRGFyaW8vSW5nZW5pZXJpYS9JbmZvcm1hzIF0aWNhIHkgc3VwZXJjb21wdXRhY2lvbiAtIE1hdGxhYiBNYXRoZW1hdGljYS9SZXBvc2l0b3Jpb3MgR2l0L0Z1bGxTdGFja09wZW4vcGFydDQvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL0FwcC5qc3gifQ==