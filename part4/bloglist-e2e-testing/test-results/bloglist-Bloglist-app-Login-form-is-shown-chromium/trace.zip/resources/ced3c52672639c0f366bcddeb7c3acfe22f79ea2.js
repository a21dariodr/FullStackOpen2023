import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=7464bf1a"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=7464bf1a"; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=7464bf1a"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const Blog = ({
  blog,
  updateBlog,
  deleteBlog
}) => {
  _s();
  const [showDetails, setShowDetails] = useState(false);
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 8,
    paddingBottom: 6,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const removeButtonStyle = {
    color: "white",
    backgroundColor: "navy",
    border: "none",
    padding: 4,
    marginTop: 6
  };
  const user = JSON.parse(localStorage.getItem("loggedUser"));
  const handleLike = () => {
    blog.likes += 1;
    updateBlog(blog);
  };
  const handleRemove = () => {
    if (window.confirm(`Blog "${blog.title}" by ${blog.author} is about to be deleted!`))
      deleteBlog(blog);
  };
  return /* @__PURE__ */ jsxDEV("div", { style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("span", { className: "blogTitle", children: blog.title }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    " - ",
    /* @__PURE__ */ jsxDEV("span", { className: "blogAuthor", children: blog.author }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 35,
      columnNumber: 57
    }, this),
    " ",
    /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowDetails(!showDetails), children: showDetails ? "Hide details" : "Show details" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 36,
      columnNumber: 7
    }, this),
    showDetails ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 38,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 38,
        columnNumber: 19
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "blogUrl", children: [
        "URL: ",
        blog.url
      ] }, void 0, true, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 39,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 39,
        columnNumber: 61
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "blogLikes", children: [
        "Likes: ",
        blog.likes
      ] }, void 0, true, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 40,
        columnNumber: 13
      }, this),
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLike, children: "Like" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 40,
        columnNumber: 68
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 40,
        columnNumber: 110
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "blogUser", children: [
        "User: ",
        blog.user.name
      ] }, void 0, true, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 41,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 41,
        columnNumber: 69
      }, this),
      user.username === blog.user.username ? /* @__PURE__ */ jsxDEV("button", { style: removeButtonStyle, onClick: handleRemove, children: "Remove" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 42,
        columnNumber: 53
      }, this) : ""
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 37,
      columnNumber: 22
    }, this) : ""
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(Blog, "n2rC7YX8Mzz154E9USQBvseY7a0=");
_c = Blog;
Blog.propTypes = {
  blog: PropTypes.object.isRequired,
  updateBlog: PropTypes.func.isRequired,
  deleteBlog: PropTypes.func.isRequired
};
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNNLFNBSUksVUFKSjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFyQ04sU0FBU0EsZ0JBQWdCO0FBQ3pCLE9BQU9DLGVBQWU7QUFFdEIsTUFBTUMsT0FBT0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQVlDO0FBQVcsTUFBTTtBQUFBQyxLQUFBO0FBQ2pELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJUixTQUFTLEtBQUs7QUFFcEQsUUFBTVMsWUFBWTtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLGVBQWU7QUFBQSxJQUNmQyxRQUFRO0FBQUEsSUFDUkMsYUFBYTtBQUFBLElBQ2JDLGNBQWM7QUFBQSxFQUNoQjtBQUVBLFFBQU1DLG9CQUFvQjtBQUFBLElBQ3hCQyxPQUFPO0FBQUEsSUFDUEMsaUJBQWlCO0FBQUEsSUFDakJMLFFBQVE7QUFBQSxJQUNSTSxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLEVBQ2I7QUFFQSxRQUFNQyxPQUFPQyxLQUFLQyxNQUFNQyxhQUFhQyxRQUFRLFlBQVksQ0FBQztBQUUxRCxRQUFNQyxhQUFhQSxNQUFNO0FBQ3ZCdkIsU0FBS3dCLFNBQVM7QUFDZHZCLGVBQVdELElBQUk7QUFBQSxFQUNqQjtBQUVBLFFBQU15QixlQUFlQSxNQUFNO0FBQ3pCLFFBQUlDLE9BQU9DLFFBQVMsU0FBUTNCLEtBQUs0QixLQUFNLFFBQU81QixLQUFLNkIsTUFBTywwQkFBeUI7QUFDakYzQixpQkFBV0YsSUFBSTtBQUFBLEVBQ25CO0FBRUEsU0FDRSx1QkFBQyxTQUFJLE9BQU9NLFdBQ1Y7QUFBQSwyQkFBQyxVQUFLLFdBQVUsYUFBYU4sZUFBSzRCLFNBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBd0M7QUFBQSxJQUFPO0FBQUEsSUFBRyx1QkFBQyxVQUFLLFdBQVUsY0FBYzVCLGVBQUs2QixVQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBDO0FBQUEsSUFBTztBQUFBLElBQ25HLHVCQUFDLFlBQU8sU0FBUyxNQUFNeEIsZUFBZSxDQUFDRCxXQUFXLEdBQUlBLHdCQUFjLGlCQUFpQixrQkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRztBQUFBLElBQ25HQSxjQUVHLG1DQUNFO0FBQUEsNkJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxNQUFFLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDUix1QkFBQyxVQUFLLFdBQVUsV0FBVTtBQUFBO0FBQUEsUUFBTUosS0FBSzhCO0FBQUFBLFdBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBeUM7QUFBQSxNQUFPLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDbkQsdUJBQUMsVUFBSyxXQUFVLGFBQVk7QUFBQTtBQUFBLFFBQVE5QixLQUFLd0I7QUFBQUEsV0FBekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErQztBQUFBLE1BQU87QUFBQSxNQUFDLHVCQUFDLFlBQU8sU0FBU0QsWUFBWSxvQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQVMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxNQUNwRyx1QkFBQyxVQUFLLFdBQVUsWUFBVztBQUFBO0FBQUEsUUFBT3ZCLEtBQUtrQixLQUFLYTtBQUFBQSxXQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWlEO0FBQUEsTUFBTyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQzFEYixLQUFLYyxhQUFhaEMsS0FBS2tCLEtBQUtjLFdBQ3hCLHVCQUFDLFlBQU8sT0FBT25CLG1CQUFtQixTQUFTWSxjQUFjLHNCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStELElBQ2hFO0FBQUEsU0FQTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0EsSUFFQTtBQUFBLE9BaEJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkE7QUFFSjtBQUFDdEIsR0FyREtKLE1BQUk7QUFBQWtDLEtBQUpsQztBQXVETkEsS0FBS21DLFlBQVk7QUFBQSxFQUNmbEMsTUFBTUYsVUFBVXFDLE9BQU9DO0FBQUFBLEVBQ3ZCbkMsWUFBWUgsVUFBVXVDLEtBQUtEO0FBQUFBLEVBQzNCbEMsWUFBWUosVUFBVXVDLEtBQUtEO0FBQzdCO0FBRUEsZUFBZXJDO0FBQUksSUFBQWtDO0FBQUFLLGFBQUFMLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlByb3BUeXBlcyIsIkJsb2ciLCJibG9nIiwidXBkYXRlQmxvZyIsImRlbGV0ZUJsb2ciLCJfcyIsInNob3dEZXRhaWxzIiwic2V0U2hvd0RldGFpbHMiLCJibG9nU3R5bGUiLCJwYWRkaW5nVG9wIiwicGFkZGluZ0xlZnQiLCJwYWRkaW5nQm90dG9tIiwiYm9yZGVyIiwiYm9yZGVyV2lkdGgiLCJtYXJnaW5Cb3R0b20iLCJyZW1vdmVCdXR0b25TdHlsZSIsImNvbG9yIiwiYmFja2dyb3VuZENvbG9yIiwicGFkZGluZyIsIm1hcmdpblRvcCIsInVzZXIiLCJKU09OIiwicGFyc2UiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiaGFuZGxlTGlrZSIsImxpa2VzIiwiaGFuZGxlUmVtb3ZlIiwid2luZG93IiwiY29uZmlybSIsInRpdGxlIiwiYXV0aG9yIiwidXJsIiwibmFtZSIsInVzZXJuYW1lIiwiX2MiLCJwcm9wVHlwZXMiLCJvYmplY3QiLCJpc1JlcXVpcmVkIiwiZnVuYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJsb2cuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5cbmNvbnN0IEJsb2cgPSAoeyBibG9nLCB1cGRhdGVCbG9nLCBkZWxldGVCbG9nIH0pID0+IHtcbiAgY29uc3QgW3Nob3dEZXRhaWxzLCBzZXRTaG93RGV0YWlsc10gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBibG9nU3R5bGUgPSB7XG4gICAgcGFkZGluZ1RvcDogMTAsXG4gICAgcGFkZGluZ0xlZnQ6IDgsXG4gICAgcGFkZGluZ0JvdHRvbTogNixcbiAgICBib3JkZXI6ICdzb2xpZCcsXG4gICAgYm9yZGVyV2lkdGg6IDEsXG4gICAgbWFyZ2luQm90dG9tOiA1LFxuICB9XG5cbiAgY29uc3QgcmVtb3ZlQnV0dG9uU3R5bGUgPSB7XG4gICAgY29sb3I6ICd3aGl0ZScsXG4gICAgYmFja2dyb3VuZENvbG9yOiAnbmF2eScsXG4gICAgYm9yZGVyOiAnbm9uZScsXG4gICAgcGFkZGluZzogNCxcbiAgICBtYXJnaW5Ub3A6IDZcbiAgfVxuXG4gIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsb2dnZWRVc2VyJykpXG5cbiAgY29uc3QgaGFuZGxlTGlrZSA9ICgpID0+IHtcbiAgICBibG9nLmxpa2VzICs9IDFcbiAgICB1cGRhdGVCbG9nKGJsb2cpXG4gIH1cblxuICBjb25zdCBoYW5kbGVSZW1vdmUgPSAoKSA9PiB7XG4gICAgaWYgKHdpbmRvdy5jb25maXJtKGBCbG9nIFwiJHtibG9nLnRpdGxlfVwiIGJ5ICR7YmxvZy5hdXRob3J9IGlzIGFib3V0IHRvIGJlIGRlbGV0ZWQhYCkpXG4gICAgICBkZWxldGVCbG9nKGJsb2cpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e2Jsb2dTdHlsZX0+XG4gICAgICA8c3BhbiBjbGFzc05hbWU9J2Jsb2dUaXRsZSc+e2Jsb2cudGl0bGV9PC9zcGFuPiAtIDxzcGFuIGNsYXNzTmFtZT0nYmxvZ0F1dGhvcic+e2Jsb2cuYXV0aG9yfTwvc3Bhbj4mbmJzcDtcbiAgICAgIDxidXR0b24gb25DbGljaz17KCkgPT4gc2V0U2hvd0RldGFpbHMoIXNob3dEZXRhaWxzKX0+e3Nob3dEZXRhaWxzID8gJ0hpZGUgZGV0YWlscycgOiAnU2hvdyBkZXRhaWxzJ308L2J1dHRvbj5cbiAgICAgIHtzaG93RGV0YWlsc1xuICAgICAgICA/IChcbiAgICAgICAgICA8PlxuICAgICAgICAgICAgPGJyLz48YnIvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdibG9nVXJsJz5VUkw6IHtibG9nLnVybH08L3NwYW4+PGJyLz5cbiAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT0nYmxvZ0xpa2VzJz5MaWtlczoge2Jsb2cubGlrZXN9PC9zcGFuPiA8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUxpa2V9Pkxpa2U8L2J1dHRvbj48YnIvPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPSdibG9nVXNlcic+VXNlcjoge2Jsb2cudXNlci5uYW1lfTwvc3Bhbj48YnIvPlxuICAgICAgICAgICAge3VzZXIudXNlcm5hbWUgPT09IGJsb2cudXNlci51c2VybmFtZVxuICAgICAgICAgICAgICA/ICg8YnV0dG9uIHN0eWxlPXtyZW1vdmVCdXR0b25TdHlsZX0gb25DbGljaz17aGFuZGxlUmVtb3ZlfT5SZW1vdmU8L2J1dHRvbj4pXG4gICAgICAgICAgICAgIDogJydcbiAgICAgICAgICAgIH1cbiAgICAgICAgICA8Lz5cbiAgICAgICAgKVxuICAgICAgICA6ICcnXG4gICAgICB9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuQmxvZy5wcm9wVHlwZXMgPSB7XG4gIGJsb2c6IFByb3BUeXBlcy5vYmplY3QuaXNSZXF1aXJlZCxcbiAgdXBkYXRlQmxvZzogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZCxcbiAgZGVsZXRlQmxvZzogUHJvcFR5cGVzLmZ1bmMuaXNSZXF1aXJlZFxufVxuXG5leHBvcnQgZGVmYXVsdCBCbG9nIl0sImZpbGUiOiIvVXNlcnMvZGFyaW8vRGVza3RvcC9EYXJpby9JbmdlbmllcmlhL0luZm9ybWHMgXRpY2EgeSBzdXBlcmNvbXB1dGFjaW9uIC0gTWF0bGFiIE1hdGhlbWF0aWNhL1JlcG9zaXRvcmlvcyBHaXQvRnVsbFN0YWNrT3Blbi9wYXJ0NC9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9CbG9nLmpzeCJ9