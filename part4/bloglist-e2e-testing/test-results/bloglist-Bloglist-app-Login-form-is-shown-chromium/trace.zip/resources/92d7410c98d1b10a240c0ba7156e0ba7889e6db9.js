import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Notification.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54f9846b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Notification.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import __vite__cjsImport3_propTypes from "/node_modules/.vite/deps/prop-types.js?v=f0424e77"; const PropTypes = __vite__cjsImport3_propTypes.__esModule ? __vite__cjsImport3_propTypes.default : __vite__cjsImport3_propTypes;
const Notification = ({
  color,
  message
}) => {
  if (!message)
    return null;
  const styles = {
    backgroundColor: "lightgrey",
    border: `2px solid ${color}`,
    borderRadius: "6px",
    color,
    padding: "8px",
    margin: "8px"
  };
  return /* @__PURE__ */ jsxDEV("div", { style: styles, children: message }, void 0, false, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Notification.jsx",
    lineNumber: 15,
    columnNumber: 10
  }, this);
};
_c = Notification;
Notification.propTypes = {
  color: PropTypes.string,
  message: PropTypes.string.isRequired
};
export default Notification;
var _c;
$RefreshReg$(_c, "Notification");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Notification.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZUk7QUFmSixPQUFPQSxvQkFBZTtBQUFZO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVsQyxNQUFNQyxlQUFlQSxDQUFDO0FBQUEsRUFBRUM7QUFBQUEsRUFBT0M7QUFBUSxNQUFNO0FBQzNDLE1BQUksQ0FBRUE7QUFBUyxXQUFPO0FBRXRCLFFBQU1DLFNBQVM7QUFBQSxJQUNiQyxpQkFBaUI7QUFBQSxJQUNqQkMsUUFBUyxhQUFZSixLQUFNO0FBQUEsSUFDM0JLLGNBQWM7QUFBQSxJQUNkTDtBQUFBQSxJQUNBTSxTQUFTO0FBQUEsSUFDVEMsUUFBUTtBQUFBLEVBQ1Y7QUFFQSxTQUNFLHVCQUFDLFNBQUksT0FBT0wsUUFDVEQscUJBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBQ08sS0FqQktUO0FBbUJOQSxhQUFhVSxZQUFZO0FBQUEsRUFDdkJULE9BQU9GLFVBQVVZO0FBQUFBLEVBQ2pCVCxTQUFTSCxVQUFVWSxPQUFPQztBQUM1QjtBQUVBLGVBQWVaO0FBQVksSUFBQVM7QUFBQUksYUFBQUosSUFBQSIsIm5hbWVzIjpbIlByb3BUeXBlcyIsIk5vdGlmaWNhdGlvbiIsImNvbG9yIiwibWVzc2FnZSIsInN0eWxlcyIsImJhY2tncm91bmRDb2xvciIsImJvcmRlciIsImJvcmRlclJhZGl1cyIsInBhZGRpbmciLCJtYXJnaW4iLCJfYyIsInByb3BUeXBlcyIsInN0cmluZyIsImlzUmVxdWlyZWQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJOb3RpZmljYXRpb24uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcydcblxuY29uc3QgTm90aWZpY2F0aW9uID0gKHsgY29sb3IsIG1lc3NhZ2UgfSkgPT4ge1xuICBpZiAoISBtZXNzYWdlKSByZXR1cm4gbnVsbFxuXG4gIGNvbnN0IHN0eWxlcyA9IHtcbiAgICBiYWNrZ3JvdW5kQ29sb3I6ICdsaWdodGdyZXknLFxuICAgIGJvcmRlcjogYDJweCBzb2xpZCAke2NvbG9yfWAsXG4gICAgYm9yZGVyUmFkaXVzOiAnNnB4JyxcbiAgICBjb2xvcjogY29sb3IsXG4gICAgcGFkZGluZzogJzhweCcsXG4gICAgbWFyZ2luOiAnOHB4J1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IHN0eWxlPXtzdHlsZXN9PlxuICAgICAge21lc3NhZ2V9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuTm90aWZpY2F0aW9uLnByb3BUeXBlcyA9IHtcbiAgY29sb3I6IFByb3BUeXBlcy5zdHJpbmcsXG4gIG1lc3NhZ2U6IFByb3BUeXBlcy5zdHJpbmcuaXNSZXF1aXJlZFxufVxuXG5leHBvcnQgZGVmYXVsdCBOb3RpZmljYXRpb24iXSwiZmlsZSI6Ii9Vc2Vycy9kYXJpby9EZXNrdG9wL0RhcmlvL0luZ2VuaWVyaWEvSW5mb3JtYcyBdGljYSB5IHN1cGVyY29tcHV0YWNpb24gLSBNYXRsYWIgTWF0aGVtYXRpY2EvUmVwb3NpdG9yaW9zIEdpdC9GdWxsU3RhY2tPcGVuL3BhcnQ0L2Jsb2dsaXN0LWZyb250ZW5kL3NyYy9jb21wb25lbnRzL05vdGlmaWNhdGlvbi5qc3gifQ==