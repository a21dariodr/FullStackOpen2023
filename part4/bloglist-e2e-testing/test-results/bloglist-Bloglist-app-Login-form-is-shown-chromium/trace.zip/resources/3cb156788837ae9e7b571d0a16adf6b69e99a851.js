import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AddBlogForm.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54f9846b"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=54f9846b"; const useState = __vite__cjsImport3_react["useState"];
const AddBlogForm = ({
  createBlog,
  togglableRef
}) => {
  _s();
  const [newBlogTitle, setNewBlogTitle] = useState("");
  const [newBlogAuthor, setNewBlogAuthor] = useState("");
  const [newBlogUrl, setNewBlogUrl] = useState("");
  const handleCreateBlog = (event) => {
    event.preventDefault();
    createBlog({
      title: newBlogTitle,
      author: newBlogAuthor,
      url: newBlogUrl
    });
    setNewBlogAuthor("");
    setNewBlogTitle("");
    setNewBlogUrl("");
  };
  return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("form", { onSubmit: handleCreateBlog, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Create blog" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
      lineNumber: 24,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: "Title " }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
        lineNumber: 26,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("input", { "data-testid": "newBlogTitle", type: "text", value: newBlogTitle, onChange: ({
        target
      }) => setNewBlogTitle(target.value), name: "newBlogTitle", id: "blogTitle" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
        lineNumber: 27,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
      lineNumber: 25,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: "Author " }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
        lineNumber: 32,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("input", { "data-testid": "newBlogAuthor", type: "text", value: newBlogAuthor, onChange: ({
        target
      }) => setNewBlogAuthor(target.value), name: "newBlogAuthor", id: "blogAuthor" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
        lineNumber: 33,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
      lineNumber: 31,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: "URL " }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
        lineNumber: 38,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("input", { "data-testid": "newBlogUrl", type: "text", value: newBlogUrl, onChange: ({
        target
      }) => setNewBlogUrl(target.value), name: "newBlogUrl", id: "blogUrl" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
        lineNumber: 39,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
      lineNumber: 37,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
      lineNumber: 43,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("button", { type: "submit", children: "Save blog" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
        lineNumber: 45,
        columnNumber: 11
      }, this),
      " ",
      /* @__PURE__ */ jsxDEV("button", { type: "button", onClick: () => togglableRef.current.toggleVisibility(), children: "Cancel" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
        lineNumber: 46,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
      lineNumber: 44,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
    lineNumber: 23,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx",
    lineNumber: 22,
    columnNumber: 10
  }, this);
};
_s(AddBlogForm, "oRSx/YleXhTdtqEheKafKEQyZ9Q=");
_c = AddBlogForm;
export default AddBlogForm;
var _c;
$RefreshReg$(_c, "AddBlogForm");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/AddBlogForm.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBd0JROzs7Ozs7Ozs7Ozs7Ozs7OztBQXhCUixTQUFTQSxnQkFBZ0I7QUFFekIsTUFBTUMsY0FBY0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQVlDO0FBQWEsTUFBTTtBQUFBQyxLQUFBO0FBQ3BELFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJTixTQUFTLEVBQUU7QUFDbkQsUUFBTSxDQUFDTyxlQUFlQyxnQkFBZ0IsSUFBSVIsU0FBUyxFQUFFO0FBQ3JELFFBQU0sQ0FBQ1MsWUFBWUMsYUFBYSxJQUFJVixTQUFTLEVBQUU7QUFFL0MsUUFBTVcsbUJBQW9CQyxXQUFVO0FBQ2xDQSxVQUFNQyxlQUFlO0FBRXJCWCxlQUFXO0FBQUEsTUFDVFksT0FBT1Q7QUFBQUEsTUFDUFUsUUFBUVI7QUFBQUEsTUFDUlMsS0FBS1A7QUFBQUEsSUFDUCxDQUFDO0FBRURELHFCQUFpQixFQUFFO0FBQ25CRixvQkFBZ0IsRUFBRTtBQUNsQkksa0JBQWMsRUFBRTtBQUFBLEVBQ2xCO0FBRUEsU0FDRSx1QkFBQyxTQUNDLGlDQUFDLFVBQUssVUFBVUMsa0JBQ2Q7QUFBQSwyQkFBQyxRQUFHLDJCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZTtBQUFBLElBQ2YsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFVBQUssc0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFZO0FBQUEsTUFDWix1QkFBQyxXQUFNLGVBQVksZ0JBQWUsTUFBSyxRQUFPLE9BQU9OLGNBQWMsVUFBVSxDQUFDO0FBQUEsUUFBRVk7QUFBQUEsTUFBTyxNQUFNWCxnQkFBZ0JXLE9BQU9DLEtBQUssR0FBRyxNQUFLLGdCQUFlLElBQUcsZUFBbko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE4SjtBQUFBLFNBRmhLO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFVBQUssdUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFhO0FBQUEsTUFDYix1QkFBQyxXQUFNLGVBQVksaUJBQWdCLE1BQUssUUFBTyxPQUFPWCxlQUFlLFVBQVUsQ0FBQztBQUFBLFFBQUVVO0FBQUFBLE1BQU8sTUFBTVQsaUJBQWlCUyxPQUFPQyxLQUFLLEdBQUcsTUFBSyxpQkFBZ0IsSUFBRyxnQkFBdko7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFtSztBQUFBLFNBRnJLO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFVBQUssb0JBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFVO0FBQUEsTUFDVix1QkFBQyxXQUFNLGVBQVksY0FBYSxNQUFLLFFBQU8sT0FBT1QsWUFBWSxVQUFVLENBQUM7QUFBQSxRQUFFUTtBQUFBQSxNQUFPLE1BQU1QLGNBQWNPLE9BQU9DLEtBQUssR0FBRyxNQUFLLGNBQWEsSUFBRyxhQUEzSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9KO0FBQUEsU0FGdEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ0gsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFlBQU8sTUFBSyxVQUFTLHlCQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStCO0FBQUEsTUFBUztBQUFBLE1BQ3hDLHVCQUFDLFlBQU8sTUFBSyxVQUFTLFNBQVMsTUFBTWYsYUFBYWdCLFFBQVFDLGlCQUFpQixHQUFHLHNCQUE5RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW9GO0FBQUEsU0FGdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsT0FsQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1CQSxLQXBCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBcUJBO0FBRUo7QUFBQ2hCLEdBM0NLSCxhQUFXO0FBQUFvQixLQUFYcEI7QUE2Q04sZUFBZUE7QUFBVyxJQUFBb0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQWRkQmxvZ0Zvcm0iLCJjcmVhdGVCbG9nIiwidG9nZ2xhYmxlUmVmIiwiX3MiLCJuZXdCbG9nVGl0bGUiLCJzZXROZXdCbG9nVGl0bGUiLCJuZXdCbG9nQXV0aG9yIiwic2V0TmV3QmxvZ0F1dGhvciIsIm5ld0Jsb2dVcmwiLCJzZXROZXdCbG9nVXJsIiwiaGFuZGxlQ3JlYXRlQmxvZyIsImV2ZW50IiwicHJldmVudERlZmF1bHQiLCJ0aXRsZSIsImF1dGhvciIsInVybCIsInRhcmdldCIsInZhbHVlIiwiY3VycmVudCIsInRvZ2dsZVZpc2liaWxpdHkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFkZEJsb2dGb3JtLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuXG5jb25zdCBBZGRCbG9nRm9ybSA9ICh7IGNyZWF0ZUJsb2csIHRvZ2dsYWJsZVJlZiB9KSA9PiB7XG4gIGNvbnN0IFtuZXdCbG9nVGl0bGUsIHNldE5ld0Jsb2dUaXRsZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW25ld0Jsb2dBdXRob3IsIHNldE5ld0Jsb2dBdXRob3JdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtuZXdCbG9nVXJsLCBzZXROZXdCbG9nVXJsXSA9IHVzZVN0YXRlKCcnKVxuXG4gIGNvbnN0IGhhbmRsZUNyZWF0ZUJsb2cgPSAoZXZlbnQpID0+IHtcbiAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpXG5cbiAgICBjcmVhdGVCbG9nKHtcbiAgICAgIHRpdGxlOiBuZXdCbG9nVGl0bGUsXG4gICAgICBhdXRob3I6IG5ld0Jsb2dBdXRob3IsXG4gICAgICB1cmw6IG5ld0Jsb2dVcmxcbiAgICB9KVxuXG4gICAgc2V0TmV3QmxvZ0F1dGhvcignJylcbiAgICBzZXROZXdCbG9nVGl0bGUoJycpXG4gICAgc2V0TmV3QmxvZ1VybCgnJylcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVDcmVhdGVCbG9nfT5cbiAgICAgICAgPGgyPkNyZWF0ZSBibG9nPC9oMj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8c3Bhbj5UaXRsZSA8L3NwYW4+XG4gICAgICAgICAgPGlucHV0IGRhdGEtdGVzdGlkPSduZXdCbG9nVGl0bGUnIHR5cGU9J3RleHQnIHZhbHVlPXtuZXdCbG9nVGl0bGV9IG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0TmV3QmxvZ1RpdGxlKHRhcmdldC52YWx1ZSl9IG5hbWU9J25ld0Jsb2dUaXRsZScgaWQ9J2Jsb2dUaXRsZScvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8c3Bhbj5BdXRob3IgPC9zcGFuPlxuICAgICAgICAgIDxpbnB1dCBkYXRhLXRlc3RpZD0nbmV3QmxvZ0F1dGhvcicgdHlwZT0ndGV4dCcgdmFsdWU9e25ld0Jsb2dBdXRob3J9IG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0TmV3QmxvZ0F1dGhvcih0YXJnZXQudmFsdWUpfSBuYW1lPSduZXdCbG9nQXV0aG9yJyBpZD0nYmxvZ0F1dGhvcicvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8c3Bhbj5VUkwgPC9zcGFuPlxuICAgICAgICAgIDxpbnB1dCBkYXRhLXRlc3RpZD0nbmV3QmxvZ1VybCcgdHlwZT0ndGV4dCcgdmFsdWU9e25ld0Jsb2dVcmx9IG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0TmV3QmxvZ1VybCh0YXJnZXQudmFsdWUpfSBuYW1lPSduZXdCbG9nVXJsJyBpZD0nYmxvZ1VybCcvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGJyLz5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICA8YnV0dG9uIHR5cGU9J3N1Ym1pdCc+U2F2ZSBibG9nPC9idXR0b24+Jm5ic3A7XG4gICAgICAgICAgPGJ1dHRvbiB0eXBlPSdidXR0b24nIG9uQ2xpY2s9eygpID0+IHRvZ2dsYWJsZVJlZi5jdXJyZW50LnRvZ2dsZVZpc2liaWxpdHkoKX0+Q2FuY2VsPC9idXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9mb3JtPlxuICAgIDwvZGl2PlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFkZEJsb2dGb3JtIl0sImZpbGUiOiIvVXNlcnMvZGFyaW8vRGVza3RvcC9EYXJpby9JbmdlbmllcmlhL0luZm9ybWHMgXRpY2EgeSBzdXBlcmNvbXB1dGFjaW9uIC0gTWF0bGFiIE1hdGhlbWF0aWNhL1JlcG9zaXRvcmlvcyBHaXQvRnVsbFN0YWNrT3Blbi9wYXJ0NC9ibG9nbGlzdC1mcm9udGVuZC9zcmMvY29tcG9uZW50cy9BZGRCbG9nRm9ybS5qc3gifQ==