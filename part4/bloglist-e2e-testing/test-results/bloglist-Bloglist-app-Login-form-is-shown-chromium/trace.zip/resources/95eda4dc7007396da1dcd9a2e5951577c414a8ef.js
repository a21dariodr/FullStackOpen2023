import {
  require_react
} from "/node_modules/.vite/deps/chunk-7JGOPB4S.js?v=7464bf1a";
import "/node_modules/.vite/deps/chunk-6TJCVOLN.js?v=7464bf1a";
export default require_react();
//# sourceMappingURL=react.js.map
