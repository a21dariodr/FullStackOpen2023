import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54f9846b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=54f9846b"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import AddBlogForm from "/src/components/AddBlogForm.jsx";
import Blog from "/src/components/Blog.jsx";
import Notification from "/src/components/Notification.jsx";
import Togglable from "/src/components/Togglable.jsx";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState("");
  const togglableRef = useRef();
  useEffect(() => {
    const userJSON = localStorage.getItem("loggedUser");
    if (userJSON) {
      const user2 = JSON.parse(userJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  useEffect(() => {
    if (user) {
      blogService.getAll().then((blogs2) => {
        setBlogs(sortBlogsByLikes(blogs2));
      });
    }
  }, [user]);
  const sortBlogsByLikes = (blogs2) => blogs2.sort((a, b) => b.likes - a.likes);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      console.log("Logging in with", username, password);
      blogService.setToken(user2.token);
      localStorage.setItem("loggedUser", JSON.stringify(user2));
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      console.log("Invalid username or password");
      setMessage("Invalid username or password");
      setTimeout(() => {
        setMessage("");
      }, 6e3);
    }
  };
  const handleLogout = () => {
    localStorage.removeItem("loggedUser");
    setUser(null);
  };
  const createBlog = async (newBlog) => {
    try {
      const createdBlog = await blogService.createBlog({
        title: newBlog.title,
        author: newBlog.author,
        url: newBlog.url
      });
      setBlogs(blogs.concat(createdBlog));
      togglableRef.current.toggleVisibility();
      setMessage(`New blog "${createdBlog.title}" by ${createdBlog.author} added`);
      setTimeout(() => {
        setMessage("");
      }, 6e3);
    } catch (exception) {
      console.log("Error when creating new blog");
    }
  };
  const updateBlog = async (modifiedBlog) => {
    try {
      const updatedBlog = await blogService.updateBlog(modifiedBlog);
      const filteredBlogs = blogs.filter((blog) => blog.id !== modifiedBlog.id);
      setBlogs(sortBlogsByLikes(filteredBlogs.concat(modifiedBlog)));
    } catch (exception) {
      console.log("Error when updating the blog");
    }
  };
  const deleteBlog = async (blogToDelete) => {
    try {
      await blogService.deleteBlog(blogToDelete);
      const filteredBlogs = blogs.filter((blog) => blog.id !== blogToDelete.id);
      setBlogs(sortBlogsByLikes(filteredBlogs));
    } catch (exception) {
      console.log("Error when deleting the blog");
    }
  };
  const loginForm = () => /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Log in to application" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 94,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message, color: "red" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 95,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: "Username " }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 97,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { type: "text", value: username, onChange: ({
        target
      }) => setUsername(target.value), name: "username" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 98,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 96,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: "Password " }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 103,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { type: "password", value: password, onChange: ({
        target
      }) => setPassword(target.value), name: "password" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 104,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 108,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { "data-testid": "submitButton", type: "submit", children: "Login" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 109,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 93,
    columnNumber: 27
  }, this);
  const blogsList = () => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Blogs" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 112,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      user.name,
      " is logged in  ",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "Logout" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 114,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 113,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 115,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: blogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, updateBlog, deleteBlog }, blog.id, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 117,
      columnNumber: 28
    }, this)) }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 116,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 111,
    columnNumber: 27
  }, this);
  const loggedUserContent = () => /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "Add blog", ref: togglableRef, children: /* @__PURE__ */ jsxDEV(AddBlogForm, { createBlog, togglableRef }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 122,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 121,
      columnNumber: 7
    }, this),
    blogsList()
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 120,
    columnNumber: 35
  }, this);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("h1", { children: "Bloglist app" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 127,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message, color: "green" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 128,
      columnNumber: 7
    }, this),
    user ? loggedUserContent() : loginForm()
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 126,
    columnNumber: 10
  }, this);
};
_s(App, "qp2PNB1xyqY9CDCako70TaheT1U=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUdNLFNBOEJGLFVBOUJFOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZHTixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFFekIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJWixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDYSxVQUFVQyxXQUFXLElBQUlkLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNlLFVBQVVDLFdBQVcsSUFBSWhCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNpQixNQUFNQyxPQUFPLElBQUlsQixTQUFTLElBQUk7QUFFckMsUUFBTSxDQUFDbUIsU0FBU0MsVUFBVSxJQUFJcEIsU0FBUyxFQUFFO0FBRXpDLFFBQU1xQixlQUFlbkIsT0FBTztBQUU1QkQsWUFBVSxNQUFNO0FBQ2QsVUFBTXFCLFdBQVdDLGFBQWFDLFFBQVEsWUFBWTtBQUVsRCxRQUFJRixVQUFVO0FBQ1osWUFBTUwsUUFBT1EsS0FBS0MsTUFBTUosUUFBUTtBQUNoQ0osY0FBUUQsS0FBSTtBQUNaVixrQkFBWW9CLFNBQVNWLE1BQUtXLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwzQixZQUFVLE1BQU07QUFDZCxRQUFJZ0IsTUFBTTtBQUNSVixrQkFBWXNCLE9BQU8sRUFBRUMsS0FBS25CLFlBQVM7QUFDakNDLGlCQUFTbUIsaUJBQWlCcEIsTUFBSyxDQUFDO0FBQUEsTUFDbEMsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLEdBQUcsQ0FBQ00sSUFBSSxDQUFDO0FBRVQsUUFBTWMsbUJBQW1CcEIsWUFBU0EsT0FBTXFCLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRUMsUUFBUUYsRUFBRUUsS0FBSztBQUV4RSxRQUFNQyxjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFFckIsUUFBSTtBQUNGLFlBQU1yQixRQUFPLE1BQU1ULGFBQWErQixNQUFNO0FBQUEsUUFBRTFCO0FBQUFBLFFBQVVFO0FBQUFBLE1BQVMsQ0FBQztBQUU1RHlCLGNBQVFDLElBQUksbUJBQW1CNUIsVUFBVUUsUUFBUTtBQUNqRFIsa0JBQVlvQixTQUFTVixNQUFLVyxLQUFLO0FBQy9CTCxtQkFBYW1CLFFBQVEsY0FBY2pCLEtBQUtrQixVQUFVMUIsS0FBSSxDQUFDO0FBQ3ZEQyxjQUFRRCxLQUFJO0FBQ1pILGtCQUFZLEVBQUU7QUFDZEUsa0JBQVksRUFBRTtBQUFBLElBQ2hCLFNBQVE0QixXQUFXO0FBQ2pCSixjQUFRQyxJQUFJLDhCQUE4QjtBQUUxQ3JCLGlCQUFXLDhCQUE4QjtBQUN6Q3lCLGlCQUFXLE1BQU07QUFDZnpCLG1CQUFXLEVBQUU7QUFBQSxNQUNmLEdBQUcsR0FBSTtBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTTBCLGVBQWVBLE1BQU07QUFDekJ2QixpQkFBYXdCLFdBQVcsWUFBWTtBQUNwQzdCLFlBQVEsSUFBSTtBQUFBLEVBQ2Q7QUFFQSxRQUFNOEIsYUFBYSxPQUFPQyxZQUFZO0FBQ3BDLFFBQUk7QUFDRixZQUFNQyxjQUFjLE1BQU0zQyxZQUFZeUMsV0FBVztBQUFBLFFBQUVHLE9BQU9GLFFBQVFFO0FBQUFBLFFBQU9DLFFBQVFILFFBQVFHO0FBQUFBLFFBQVFDLEtBQUtKLFFBQVFJO0FBQUFBLE1BQUksQ0FBQztBQUNuSHpDLGVBQVNELE1BQU0yQyxPQUFPSixXQUFXLENBQUM7QUFFbEM3QixtQkFBYWtDLFFBQVFDLGlCQUFpQjtBQUV0Q3BDLGlCQUFZLGFBQVk4QixZQUFZQyxLQUFNLFFBQU9ELFlBQVlFLE1BQU8sUUFBTztBQUMzRVAsaUJBQVcsTUFBTTtBQUNmekIsbUJBQVcsRUFBRTtBQUFBLE1BQ2YsR0FBRyxHQUFJO0FBQUEsSUFDVCxTQUFTd0IsV0FBVztBQUNsQkosY0FBUUMsSUFBSSw4QkFBOEI7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0IsYUFBYSxPQUFNQyxpQkFBZ0I7QUFDdkMsUUFBSTtBQUNGLFlBQU1DLGNBQWMsTUFBTXBELFlBQVlrRCxXQUFXQyxZQUFZO0FBQzdELFlBQU1FLGdCQUFnQmpELE1BQU1rRCxPQUFPQyxVQUFRQSxLQUFLQyxPQUFPTCxhQUFhSyxFQUFFO0FBQ3RFbkQsZUFBU21CLGlCQUFpQjZCLGNBQWNOLE9BQU9JLFlBQVksQ0FBQyxDQUFDO0FBQUEsSUFDL0QsU0FBU2QsV0FBVztBQUNsQkosY0FBUUMsSUFBSSw4QkFBOEI7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFFQSxRQUFNdUIsYUFBYSxPQUFNQyxpQkFBZ0I7QUFDdkMsUUFBSTtBQUNGLFlBQU0xRCxZQUFZeUQsV0FBV0MsWUFBWTtBQUN6QyxZQUFNTCxnQkFBZ0JqRCxNQUFNa0QsT0FBT0MsVUFBUUEsS0FBS0MsT0FBT0UsYUFBYUYsRUFBRTtBQUN0RW5ELGVBQVNtQixpQkFBaUI2QixhQUFhLENBQUM7QUFBQSxJQUMxQyxTQUFTaEIsV0FBVztBQUNsQkosY0FBUUMsSUFBSSw4QkFBOEI7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFFQSxRQUFNeUIsWUFBWUEsTUFDaEIsdUJBQUMsVUFBSyxVQUFVOUIsYUFDZDtBQUFBLDJCQUFDLFFBQUcscUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUFBLElBQ3pCLHVCQUFDLGdCQUFhLFNBQWtCLE9BQU8sU0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QztBQUFBLElBQzdDLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxVQUFLLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2YsdUJBQUMsV0FBTSxNQUFLLFFBQU8sT0FBT3ZCLFVBQVUsVUFBVSxDQUFDO0FBQUEsUUFBRXNEO0FBQUFBLE1BQU8sTUFBTXJELFlBQVlxRCxPQUFPQyxLQUFLLEdBQUcsTUFBSyxjQUE5RjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXdHO0FBQUEsU0FGMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxTQUNDO0FBQUEsNkJBQUMsVUFBSyx5QkFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWU7QUFBQSxNQUNmLHVCQUFDLFdBQU0sTUFBSyxZQUFXLE9BQU9yRCxVQUFVLFVBQVUsQ0FBQztBQUFBLFFBQUVvRDtBQUFBQSxNQUFPLE1BQU1uRCxZQUFZbUQsT0FBT0MsS0FBSyxHQUFHLE1BQUssY0FBbEc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUE0RztBQUFBLFNBRjlHO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUc7QUFBQSxJQUNILHVCQUFDLFlBQU8sZUFBWSxnQkFBZSxNQUFLLFVBQVMscUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBc0Q7QUFBQSxPQVp4RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBYUE7QUFHRixRQUFNQyxZQUFZQSxNQUNoQix1QkFBQyxTQUNDO0FBQUEsMkJBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVM7QUFBQSxJQUNULHVCQUFDLFNBQUtwRDtBQUFBQSxXQUFLcUQ7QUFBQUEsTUFBSztBQUFBLE1BQ1IsdUJBQUMsWUFBTyxTQUFTeEIsY0FBYyxzQkFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFxQztBQUFBLFNBRDdDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FDc0Q7QUFBQSxJQUN0RCx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ0gsdUJBQUMsU0FDRW5DLGdCQUFNNEQsSUFBSVQsVUFDVCx1QkFBQyxRQUFtQixNQUFZLFlBQXdCLGNBQTdDQSxLQUFLQyxJQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQStFLENBQ2pGLEtBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUlBO0FBQUEsT0FURjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBVUE7QUFHRixRQUFNUyxvQkFBb0JBLE1BQ3hCLG1DQUNFO0FBQUEsMkJBQUMsYUFBVSxhQUFZLFlBQVcsS0FBS25ELGNBQ3JDLGlDQUFDLGVBQVksWUFBd0IsZ0JBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0UsS0FEbEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQ2dELFVBQVU7QUFBQSxPQUpiO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FLQTtBQUdGLFNBQ0UsbUNBQ0U7QUFBQSwyQkFBQyxRQUFHLDRCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBZ0I7QUFBQSxJQUNoQix1QkFBQyxnQkFBYSxTQUFrQixPQUFPLFdBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0M7QUFBQSxJQUM5Q3BELE9BQ0d1RCxrQkFBa0IsSUFDbEJOLFVBQVU7QUFBQSxPQUxoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBT0E7QUFFSjtBQUFDeEQsR0EvSUtELEtBQUc7QUFBQWdFLEtBQUhoRTtBQWlKTixlQUFlQTtBQUFHLElBQUFnRTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJ1c2VFZmZlY3QiLCJ1c2VSZWYiLCJBZGRCbG9nRm9ybSIsIkJsb2ciLCJOb3RpZmljYXRpb24iLCJUb2dnbGFibGUiLCJibG9nU2VydmljZSIsImxvZ2luU2VydmljZSIsIkFwcCIsIl9zIiwiYmxvZ3MiLCJzZXRCbG9ncyIsInVzZXJuYW1lIiwic2V0VXNlcm5hbWUiLCJwYXNzd29yZCIsInNldFBhc3N3b3JkIiwidXNlciIsInNldFVzZXIiLCJtZXNzYWdlIiwic2V0TWVzc2FnZSIsInRvZ2dsYWJsZVJlZiIsInVzZXJKU09OIiwibG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsIkpTT04iLCJwYXJzZSIsInNldFRva2VuIiwidG9rZW4iLCJnZXRBbGwiLCJ0aGVuIiwic29ydEJsb2dzQnlMaWtlcyIsInNvcnQiLCJhIiwiYiIsImxpa2VzIiwiaGFuZGxlTG9naW4iLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwibG9naW4iLCJjb25zb2xlIiwibG9nIiwic2V0SXRlbSIsInN0cmluZ2lmeSIsImV4Y2VwdGlvbiIsInNldFRpbWVvdXQiLCJoYW5kbGVMb2dvdXQiLCJyZW1vdmVJdGVtIiwiY3JlYXRlQmxvZyIsIm5ld0Jsb2ciLCJjcmVhdGVkQmxvZyIsInRpdGxlIiwiYXV0aG9yIiwidXJsIiwiY29uY2F0IiwiY3VycmVudCIsInRvZ2dsZVZpc2liaWxpdHkiLCJ1cGRhdGVCbG9nIiwibW9kaWZpZWRCbG9nIiwidXBkYXRlZEJsb2ciLCJmaWx0ZXJlZEJsb2dzIiwiZmlsdGVyIiwiYmxvZyIsImlkIiwiZGVsZXRlQmxvZyIsImJsb2dUb0RlbGV0ZSIsImxvZ2luRm9ybSIsInRhcmdldCIsInZhbHVlIiwiYmxvZ3NMaXN0IiwibmFtZSIsIm1hcCIsImxvZ2dlZFVzZXJDb250ZW50IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlLCB1c2VFZmZlY3QsIHVzZVJlZiB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IEFkZEJsb2dGb3JtIGZyb20gJy4vY29tcG9uZW50cy9BZGRCbG9nRm9ybSdcbmltcG9ydCBCbG9nIGZyb20gJy4vY29tcG9uZW50cy9CbG9nJ1xuaW1wb3J0IE5vdGlmaWNhdGlvbiBmcm9tICcuL2NvbXBvbmVudHMvTm90aWZpY2F0aW9uJ1xuaW1wb3J0IFRvZ2dsYWJsZSBmcm9tICcuL2NvbXBvbmVudHMvVG9nZ2xhYmxlJ1xuaW1wb3J0IGJsb2dTZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvYmxvZ3MnXG5pbXBvcnQgbG9naW5TZXJ2aWNlIGZyb20gJy4vc2VydmljZXMvbG9naW4nXG5cbmNvbnN0IEFwcCA9ICgpID0+IHtcbiAgY29uc3QgW2Jsb2dzLCBzZXRCbG9nc10gPSB1c2VTdGF0ZShbXSlcbiAgY29uc3QgW3VzZXJuYW1lLCBzZXRVc2VybmFtZV0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZSgnJylcbiAgY29uc3QgW3VzZXIsIHNldFVzZXJdID0gdXNlU3RhdGUobnVsbClcblxuICBjb25zdCBbbWVzc2FnZSwgc2V0TWVzc2FnZV0gPSB1c2VTdGF0ZSgnJylcblxuICBjb25zdCB0b2dnbGFibGVSZWYgPSB1c2VSZWYoKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgdXNlckpTT04gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnbG9nZ2VkVXNlcicpXG5cbiAgICBpZiAodXNlckpTT04pIHtcbiAgICAgIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKHVzZXJKU09OKVxuICAgICAgc2V0VXNlcih1c2VyKVxuICAgICAgYmxvZ1NlcnZpY2Uuc2V0VG9rZW4odXNlci50b2tlbilcbiAgICB9XG4gIH0sIFtdKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKHVzZXIpIHtcbiAgICAgIGJsb2dTZXJ2aWNlLmdldEFsbCgpLnRoZW4oYmxvZ3MgPT4ge1xuICAgICAgICBzZXRCbG9ncyhzb3J0QmxvZ3NCeUxpa2VzKGJsb2dzKSlcbiAgICAgIH0pXG4gICAgfVxuICB9LCBbdXNlcl0pXG5cbiAgY29uc3Qgc29ydEJsb2dzQnlMaWtlcyA9IGJsb2dzID0+IGJsb2dzLnNvcnQoKGEsIGIpID0+IGIubGlrZXMgLSBhLmxpa2VzKVxuXG4gIGNvbnN0IGhhbmRsZUxvZ2luID0gYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgZXZlbnQucHJldmVudERlZmF1bHQoKVxuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHVzZXIgPSBhd2FpdCBsb2dpblNlcnZpY2UubG9naW4oeyB1c2VybmFtZSwgcGFzc3dvcmQgfSlcblxuICAgICAgY29uc29sZS5sb2coJ0xvZ2dpbmcgaW4gd2l0aCcsIHVzZXJuYW1lLCBwYXNzd29yZClcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgnbG9nZ2VkVXNlcicsIEpTT04uc3RyaW5naWZ5KHVzZXIpKVxuICAgICAgc2V0VXNlcih1c2VyKVxuICAgICAgc2V0VXNlcm5hbWUoJycpXG4gICAgICBzZXRQYXNzd29yZCgnJylcbiAgICB9IGNhdGNoKGV4Y2VwdGlvbikge1xuICAgICAgY29uc29sZS5sb2coJ0ludmFsaWQgdXNlcm5hbWUgb3IgcGFzc3dvcmQnKVxuXG4gICAgICBzZXRNZXNzYWdlKCdJbnZhbGlkIHVzZXJuYW1lIG9yIHBhc3N3b3JkJylcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXRNZXNzYWdlKCcnKVxuICAgICAgfSwgNjAwMClcbiAgICB9XG4gIH1cblxuICBjb25zdCBoYW5kbGVMb2dvdXQgPSAoKSA9PiB7XG4gICAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2xvZ2dlZFVzZXInKVxuICAgIHNldFVzZXIobnVsbClcbiAgfVxuXG4gIGNvbnN0IGNyZWF0ZUJsb2cgPSBhc3luYyAobmV3QmxvZykgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBjcmVhdGVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLmNyZWF0ZUJsb2coeyB0aXRsZTogbmV3QmxvZy50aXRsZSwgYXV0aG9yOiBuZXdCbG9nLmF1dGhvciwgdXJsOiBuZXdCbG9nLnVybCB9KVxuICAgICAgc2V0QmxvZ3MoYmxvZ3MuY29uY2F0KGNyZWF0ZWRCbG9nKSlcblxuICAgICAgdG9nZ2xhYmxlUmVmLmN1cnJlbnQudG9nZ2xlVmlzaWJpbGl0eSgpXG5cbiAgICAgIHNldE1lc3NhZ2UoYE5ldyBibG9nIFwiJHtjcmVhdGVkQmxvZy50aXRsZX1cIiBieSAke2NyZWF0ZWRCbG9nLmF1dGhvcn0gYWRkZWRgKVxuICAgICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIHNldE1lc3NhZ2UoJycpXG4gICAgICB9LCA2MDAwKVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgY29uc29sZS5sb2coJ0Vycm9yIHdoZW4gY3JlYXRpbmcgbmV3IGJsb2cnKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IHVwZGF0ZUJsb2cgPSBhc3luYyBtb2RpZmllZEJsb2cgPT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB1cGRhdGVkQmxvZyA9IGF3YWl0IGJsb2dTZXJ2aWNlLnVwZGF0ZUJsb2cobW9kaWZpZWRCbG9nKVxuICAgICAgY29uc3QgZmlsdGVyZWRCbG9ncyA9IGJsb2dzLmZpbHRlcihibG9nID0+IGJsb2cuaWQgIT09IG1vZGlmaWVkQmxvZy5pZClcbiAgICAgIHNldEJsb2dzKHNvcnRCbG9nc0J5TGlrZXMoZmlsdGVyZWRCbG9ncy5jb25jYXQobW9kaWZpZWRCbG9nKSkpXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICBjb25zb2xlLmxvZygnRXJyb3Igd2hlbiB1cGRhdGluZyB0aGUgYmxvZycpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgZGVsZXRlQmxvZyA9IGFzeW5jIGJsb2dUb0RlbGV0ZSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IGJsb2dTZXJ2aWNlLmRlbGV0ZUJsb2coYmxvZ1RvRGVsZXRlKVxuICAgICAgY29uc3QgZmlsdGVyZWRCbG9ncyA9IGJsb2dzLmZpbHRlcihibG9nID0+IGJsb2cuaWQgIT09IGJsb2dUb0RlbGV0ZS5pZClcbiAgICAgIHNldEJsb2dzKHNvcnRCbG9nc0J5TGlrZXMoZmlsdGVyZWRCbG9ncykpXG4gICAgfSBjYXRjaCAoZXhjZXB0aW9uKSB7XG4gICAgICBjb25zb2xlLmxvZygnRXJyb3Igd2hlbiBkZWxldGluZyB0aGUgYmxvZycpXG4gICAgfVxuICB9XG5cbiAgY29uc3QgbG9naW5Gb3JtID0gKCkgPT4gKFxuICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVMb2dpbn0+XG4gICAgICA8aDI+TG9nIGluIHRvIGFwcGxpY2F0aW9uPC9oMj5cbiAgICAgIDxOb3RpZmljYXRpb24gbWVzc2FnZT17bWVzc2FnZX0gY29sb3I9eydyZWQnfS8+XG4gICAgICA8ZGl2PlxuICAgICAgICA8c3Bhbj5Vc2VybmFtZSA8L3NwYW4+XG4gICAgICAgIDxpbnB1dCB0eXBlPSd0ZXh0JyB2YWx1ZT17dXNlcm5hbWV9IG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VXNlcm5hbWUodGFyZ2V0LnZhbHVlKX0gbmFtZT0ndXNlcm5hbWUnLz5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdj5cbiAgICAgICAgPHNwYW4+UGFzc3dvcmQgPC9zcGFuPlxuICAgICAgICA8aW5wdXQgdHlwZT0ncGFzc3dvcmQnIHZhbHVlPXtwYXNzd29yZH0gb25DaGFuZ2U9eyh7IHRhcmdldCB9KSA9PiBzZXRQYXNzd29yZCh0YXJnZXQudmFsdWUpfSBuYW1lPSdwYXNzd29yZCcvPlxuICAgICAgPC9kaXY+XG4gICAgICA8YnIvPlxuICAgICAgPGJ1dHRvbiBkYXRhLXRlc3RpZD0nc3VibWl0QnV0dG9uJyB0eXBlPSdzdWJtaXQnPkxvZ2luPC9idXR0b24+XG4gICAgPC9mb3JtPlxuICApXG5cbiAgY29uc3QgYmxvZ3NMaXN0ID0gKCkgPT4gKFxuICAgIDxkaXY+XG4gICAgICA8aDI+QmxvZ3M8L2gyPlxuICAgICAgPGRpdj57dXNlci5uYW1lfSBpcyBsb2dnZWQgaW5cbiAgICAgICAgJm5ic3A7PGJ1dHRvbiBvbkNsaWNrPXtoYW5kbGVMb2dvdXR9PkxvZ291dDwvYnV0dG9uPjwvZGl2PlxuICAgICAgPGJyLz5cbiAgICAgIDxkaXY+XG4gICAgICAgIHtibG9ncy5tYXAoYmxvZyA9PlxuICAgICAgICAgIDxCbG9nIGtleT17YmxvZy5pZH0gYmxvZz17YmxvZ30gdXBkYXRlQmxvZz17dXBkYXRlQmxvZ30gZGVsZXRlQmxvZz17ZGVsZXRlQmxvZ30vPlxuICAgICAgICApfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gIClcblxuICBjb25zdCBsb2dnZWRVc2VyQ29udGVudCA9ICgpID0+IChcbiAgICA8PlxuICAgICAgPFRvZ2dsYWJsZSBidXR0b25MYWJlbD1cIkFkZCBibG9nXCIgcmVmPXt0b2dnbGFibGVSZWZ9PlxuICAgICAgICA8QWRkQmxvZ0Zvcm0gY3JlYXRlQmxvZz17Y3JlYXRlQmxvZ30gdG9nZ2xhYmxlUmVmPXt0b2dnbGFibGVSZWZ9Lz5cbiAgICAgIDwvVG9nZ2xhYmxlPlxuICAgICAge2Jsb2dzTGlzdCgpfVxuICAgIDwvPlxuICApXG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGgxPkJsb2dsaXN0IGFwcDwvaDE+XG4gICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e21lc3NhZ2V9IGNvbG9yPXsnZ3JlZW4nfS8+XG4gICAgICB7dXNlclxuICAgICAgICA/IGxvZ2dlZFVzZXJDb250ZW50KClcbiAgICAgICAgOiBsb2dpbkZvcm0oKVxuICAgICAgfVxuICAgIDwvPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcCJdLCJmaWxlIjoiL1VzZXJzL2RhcmlvL0Rlc2t0b3AvRGFyaW8vSW5nZW5pZXJpYS9JbmZvcm1hzIF0aWNhIHkgc3VwZXJjb21wdXRhY2lvbiAtIE1hdGxhYiBNYXRoZW1hdGljYS9SZXBvc2l0b3Jpb3MgR2l0L0Z1bGxTdGFja09wZW4vcGFydDQvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL0FwcC5qc3gifQ==