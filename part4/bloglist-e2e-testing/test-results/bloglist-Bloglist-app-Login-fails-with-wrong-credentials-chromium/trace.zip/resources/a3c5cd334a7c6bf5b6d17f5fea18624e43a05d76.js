import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/Blog.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54f9846b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=54f9846b"; const useState = __vite__cjsImport3_react["useState"];
import __vite__cjsImport4_propTypes from "/node_modules/.vite/deps/prop-types.js?v=f0424e77"; const PropTypes = __vite__cjsImport4_propTypes.__esModule ? __vite__cjsImport4_propTypes.default : __vite__cjsImport4_propTypes;
const Blog = ({
  blog,
  updateBlog,
  deleteBlog
}) => {
  _s();
  const [showDetails, setShowDetails] = useState(false);
  const blogStyle = {
    paddingTop: 10,
    paddingLeft: 8,
    paddingBottom: 6,
    border: "solid",
    borderWidth: 1,
    marginBottom: 5
  };
  const removeButtonStyle = {
    color: "white",
    backgroundColor: "navy",
    border: "none",
    padding: 4,
    marginTop: 6
  };
  const user = JSON.parse(localStorage.getItem("loggedUser"));
  const handleLike = () => {
    blog.likes += 1;
    updateBlog(blog);
  };
  const handleRemove = () => {
    if (window.confirm(`Blog "${blog.title}" by ${blog.author} is about to be deleted!`))
      deleteBlog(blog);
  };
  return /* @__PURE__ */ jsxDEV("div", { style: blogStyle, children: [
    /* @__PURE__ */ jsxDEV("span", { id: "blogTitle", children: blog.title }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this),
    " - ",
    /* @__PURE__ */ jsxDEV("span", { id: "blogAuthor", children: blog.author }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 35,
      columnNumber: 50
    }, this),
    " ",
    /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowDetails(!showDetails), children: showDetails ? "Hide details" : "Show details" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 36,
      columnNumber: 7
    }, this),
    showDetails ? /* @__PURE__ */ jsxDEV(Fragment, { children: [
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 38,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 38,
        columnNumber: 19
      }, this),
      /* @__PURE__ */ jsxDEV("span", { id: "blogUrl", children: [
        "URL: ",
        blog.url
      ] }, void 0, true, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 39,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 39,
        columnNumber: 54
      }, this),
      /* @__PURE__ */ jsxDEV("span", { id: "blogLikes", children: [
        "Likes: ",
        blog.likes
      ] }, void 0, true, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 40,
        columnNumber: 13
      }, this),
      " ",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLike, children: "Like" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 40,
        columnNumber: 61
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 40,
        columnNumber: 103
      }, this),
      /* @__PURE__ */ jsxDEV("span", { id: "blogUser", children: [
        "User: ",
        blog.user.name
      ] }, void 0, true, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 41,
        columnNumber: 13
      }, this),
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 41,
        columnNumber: 62
      }, this),
      user.username === blog.user.username ? /* @__PURE__ */ jsxDEV("button", { style: removeButtonStyle, onClick: handleRemove, children: "Remove" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
        lineNumber: 42,
        columnNumber: 53
      }, this) : ""
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
      lineNumber: 37,
      columnNumber: 22
    }, this) : ""
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
};
_s(Blog, "n2rC7YX8Mzz154E9USQBvseY7a0=");
_c = Blog;
Blog.propTypes = {
  blog: PropTypes.object.isRequired,
  updateBlog: PropTypes.func.isRequired,
  deleteBlog: PropTypes.func.isRequired
};
export default Blog;
var _c;
$RefreshReg$(_c, "Blog");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/components/Blog.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUNNLFNBSUksVUFKSjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFyQ04sU0FBU0EsZ0JBQWdCO0FBQ3pCLE9BQU9DLGVBQWU7QUFFdEIsTUFBTUMsT0FBT0EsQ0FBQztBQUFBLEVBQUVDO0FBQUFBLEVBQU1DO0FBQUFBLEVBQVlDO0FBQVcsTUFBTTtBQUFBQyxLQUFBO0FBQ2pELFFBQU0sQ0FBQ0MsYUFBYUMsY0FBYyxJQUFJUixTQUFTLEtBQUs7QUFFcEQsUUFBTVMsWUFBWTtBQUFBLElBQ2hCQyxZQUFZO0FBQUEsSUFDWkMsYUFBYTtBQUFBLElBQ2JDLGVBQWU7QUFBQSxJQUNmQyxRQUFRO0FBQUEsSUFDUkMsYUFBYTtBQUFBLElBQ2JDLGNBQWM7QUFBQSxFQUNoQjtBQUVBLFFBQU1DLG9CQUFvQjtBQUFBLElBQ3hCQyxPQUFPO0FBQUEsSUFDUEMsaUJBQWlCO0FBQUEsSUFDakJMLFFBQVE7QUFBQSxJQUNSTSxTQUFTO0FBQUEsSUFDVEMsV0FBVztBQUFBLEVBQ2I7QUFFQSxRQUFNQyxPQUFPQyxLQUFLQyxNQUFNQyxhQUFhQyxRQUFRLFlBQVksQ0FBQztBQUUxRCxRQUFNQyxhQUFhQSxNQUFNO0FBQ3ZCdkIsU0FBS3dCLFNBQVM7QUFDZHZCLGVBQVdELElBQUk7QUFBQSxFQUNqQjtBQUVBLFFBQU15QixlQUFlQSxNQUFNO0FBQ3pCLFFBQUlDLE9BQU9DLFFBQVMsU0FBUTNCLEtBQUs0QixLQUFNLFFBQU81QixLQUFLNkIsTUFBTywwQkFBeUI7QUFDakYzQixpQkFBV0YsSUFBSTtBQUFBLEVBQ25CO0FBRUEsU0FDRSx1QkFBQyxTQUFJLE9BQU9NLFdBQ1Y7QUFBQSwyQkFBQyxVQUFLLElBQUcsYUFBYU4sZUFBSzRCLFNBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBaUM7QUFBQSxJQUFPO0FBQUEsSUFBRyx1QkFBQyxVQUFLLElBQUcsY0FBYzVCLGVBQUs2QixVQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQW1DO0FBQUEsSUFBTztBQUFBLElBQ3JGLHVCQUFDLFlBQU8sU0FBUyxNQUFNeEIsZUFBZSxDQUFDRCxXQUFXLEdBQUlBLHdCQUFjLGlCQUFpQixrQkFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRztBQUFBLElBQ25HQSxjQUVHLG1DQUNFO0FBQUEsNkJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxNQUFFLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDUix1QkFBQyxVQUFLLElBQUcsV0FBVTtBQUFBO0FBQUEsUUFBTUosS0FBSzhCO0FBQUFBLFdBQTlCO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBa0M7QUFBQSxNQUFPLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDNUMsdUJBQUMsVUFBSyxJQUFHLGFBQVk7QUFBQTtBQUFBLFFBQVE5QixLQUFLd0I7QUFBQUEsV0FBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF3QztBQUFBLE1BQU87QUFBQSxNQUFDLHVCQUFDLFlBQU8sU0FBU0QsWUFBWSxvQkFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQztBQUFBLE1BQVMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQUc7QUFBQSxNQUM3Rix1QkFBQyxVQUFLLElBQUcsWUFBVztBQUFBO0FBQUEsUUFBT3ZCLEtBQUtrQixLQUFLYTtBQUFBQSxXQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTBDO0FBQUEsTUFBTyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBRztBQUFBLE1BQ25EYixLQUFLYyxhQUFhaEMsS0FBS2tCLEtBQUtjLFdBQ3hCLHVCQUFDLFlBQU8sT0FBT25CLG1CQUFtQixTQUFTWSxjQUFjLHNCQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStELElBQ2hFO0FBQUEsU0FQTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0EsSUFFQTtBQUFBLE9BaEJOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FrQkE7QUFFSjtBQUFDdEIsR0FyREtKLE1BQUk7QUFBQWtDLEtBQUpsQztBQXVETkEsS0FBS21DLFlBQVk7QUFBQSxFQUNmbEMsTUFBTUYsVUFBVXFDLE9BQU9DO0FBQUFBLEVBQ3ZCbkMsWUFBWUgsVUFBVXVDLEtBQUtEO0FBQUFBLEVBQzNCbEMsWUFBWUosVUFBVXVDLEtBQUtEO0FBQzdCO0FBRUEsZUFBZXJDO0FBQUksSUFBQWtDO0FBQUFLLGFBQUFMLElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIlByb3BUeXBlcyIsIkJsb2ciLCJibG9nIiwidXBkYXRlQmxvZyIsImRlbGV0ZUJsb2ciLCJfcyIsInNob3dEZXRhaWxzIiwic2V0U2hvd0RldGFpbHMiLCJibG9nU3R5bGUiLCJwYWRkaW5nVG9wIiwicGFkZGluZ0xlZnQiLCJwYWRkaW5nQm90dG9tIiwiYm9yZGVyIiwiYm9yZGVyV2lkdGgiLCJtYXJnaW5Cb3R0b20iLCJyZW1vdmVCdXR0b25TdHlsZSIsImNvbG9yIiwiYmFja2dyb3VuZENvbG9yIiwicGFkZGluZyIsIm1hcmdpblRvcCIsInVzZXIiLCJKU09OIiwicGFyc2UiLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwiaGFuZGxlTGlrZSIsImxpa2VzIiwiaGFuZGxlUmVtb3ZlIiwid2luZG93IiwiY29uZmlybSIsInRpdGxlIiwiYXV0aG9yIiwidXJsIiwibmFtZSIsInVzZXJuYW1lIiwiX2MiLCJwcm9wVHlwZXMiLCJvYmplY3QiLCJpc1JlcXVpcmVkIiwiZnVuYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJsb2cuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnXG5cbmNvbnN0IEJsb2cgPSAoeyBibG9nLCB1cGRhdGVCbG9nLCBkZWxldGVCbG9nIH0pID0+IHtcbiAgY29uc3QgW3Nob3dEZXRhaWxzLCBzZXRTaG93RGV0YWlsc10gPSB1c2VTdGF0ZShmYWxzZSlcblxuICBjb25zdCBibG9nU3R5bGUgPSB7XG4gICAgcGFkZGluZ1RvcDogMTAsXG4gICAgcGFkZGluZ0xlZnQ6IDgsXG4gICAgcGFkZGluZ0JvdHRvbTogNixcbiAgICBib3JkZXI6ICdzb2xpZCcsXG4gICAgYm9yZGVyV2lkdGg6IDEsXG4gICAgbWFyZ2luQm90dG9tOiA1LFxuICB9XG5cbiAgY29uc3QgcmVtb3ZlQnV0dG9uU3R5bGUgPSB7XG4gICAgY29sb3I6ICd3aGl0ZScsXG4gICAgYmFja2dyb3VuZENvbG9yOiAnbmF2eScsXG4gICAgYm9yZGVyOiAnbm9uZScsXG4gICAgcGFkZGluZzogNCxcbiAgICBtYXJnaW5Ub3A6IDZcbiAgfVxuXG4gIGNvbnN0IHVzZXIgPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5nZXRJdGVtKCdsb2dnZWRVc2VyJykpXG5cbiAgY29uc3QgaGFuZGxlTGlrZSA9ICgpID0+IHtcbiAgICBibG9nLmxpa2VzICs9IDFcbiAgICB1cGRhdGVCbG9nKGJsb2cpXG4gIH1cblxuICBjb25zdCBoYW5kbGVSZW1vdmUgPSAoKSA9PiB7XG4gICAgaWYgKHdpbmRvdy5jb25maXJtKGBCbG9nIFwiJHtibG9nLnRpdGxlfVwiIGJ5ICR7YmxvZy5hdXRob3J9IGlzIGFib3V0IHRvIGJlIGRlbGV0ZWQhYCkpXG4gICAgICBkZWxldGVCbG9nKGJsb2cpXG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e2Jsb2dTdHlsZX0+XG4gICAgICA8c3BhbiBpZD0nYmxvZ1RpdGxlJz57YmxvZy50aXRsZX08L3NwYW4+IC0gPHNwYW4gaWQ9J2Jsb2dBdXRob3InPntibG9nLmF1dGhvcn08L3NwYW4+Jm5ic3A7XG4gICAgICA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IHNldFNob3dEZXRhaWxzKCFzaG93RGV0YWlscyl9PntzaG93RGV0YWlscyA/ICdIaWRlIGRldGFpbHMnIDogJ1Nob3cgZGV0YWlscyd9PC9idXR0b24+XG4gICAgICB7c2hvd0RldGFpbHNcbiAgICAgICAgPyAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxici8+PGJyLz5cbiAgICAgICAgICAgIDxzcGFuIGlkPSdibG9nVXJsJz5VUkw6IHtibG9nLnVybH08L3NwYW4+PGJyLz5cbiAgICAgICAgICAgIDxzcGFuIGlkPSdibG9nTGlrZXMnPkxpa2VzOiB7YmxvZy5saWtlc308L3NwYW4+IDxidXR0b24gb25DbGljaz17aGFuZGxlTGlrZX0+TGlrZTwvYnV0dG9uPjxici8+XG4gICAgICAgICAgICA8c3BhbiBpZD0nYmxvZ1VzZXInPlVzZXI6IHtibG9nLnVzZXIubmFtZX08L3NwYW4+PGJyLz5cbiAgICAgICAgICAgIHt1c2VyLnVzZXJuYW1lID09PSBibG9nLnVzZXIudXNlcm5hbWVcbiAgICAgICAgICAgICAgPyAoPGJ1dHRvbiBzdHlsZT17cmVtb3ZlQnV0dG9uU3R5bGV9IG9uQ2xpY2s9e2hhbmRsZVJlbW92ZX0+UmVtb3ZlPC9idXR0b24+KVxuICAgICAgICAgICAgICA6ICcnXG4gICAgICAgICAgICB9XG4gICAgICAgICAgPC8+XG4gICAgICAgIClcbiAgICAgICAgOiAnJ1xuICAgICAgfVxuICAgIDwvZGl2PlxuICApXG59XG5cbkJsb2cucHJvcFR5cGVzID0ge1xuICBibG9nOiBQcm9wVHlwZXMub2JqZWN0LmlzUmVxdWlyZWQsXG4gIHVwZGF0ZUJsb2c6IFByb3BUeXBlcy5mdW5jLmlzUmVxdWlyZWQsXG4gIGRlbGV0ZUJsb2c6IFByb3BUeXBlcy5mdW5jLmlzUmVxdWlyZWRcbn1cblxuZXhwb3J0IGRlZmF1bHQgQmxvZyJdLCJmaWxlIjoiL1VzZXJzL2RhcmlvL0Rlc2t0b3AvRGFyaW8vSW5nZW5pZXJpYS9JbmZvcm1hzIF0aWNhIHkgc3VwZXJjb21wdXRhY2lvbiAtIE1hdGxhYiBNYXRoZW1hdGljYS9SZXBvc2l0b3Jpb3MgR2l0L0Z1bGxTdGFja09wZW4vcGFydDQvYmxvZ2xpc3QtZnJvbnRlbmQvc3JjL2NvbXBvbmVudHMvQmxvZy5qc3gifQ==