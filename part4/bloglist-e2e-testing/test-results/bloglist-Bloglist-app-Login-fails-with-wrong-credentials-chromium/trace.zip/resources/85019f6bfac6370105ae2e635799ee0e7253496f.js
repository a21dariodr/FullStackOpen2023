import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=54f9846b"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=54f9846b"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"]; const useRef = __vite__cjsImport3_react["useRef"];
import AddBlogForm from "/src/components/AddBlogForm.jsx?t=1712262955011";
import Blog from "/src/components/Blog.jsx";
import Notification from "/src/components/Notification.jsx?t=1712258538423";
import Togglable from "/src/components/Togglable.jsx?t=1712262533400";
import blogService from "/src/services/blogs.js";
import loginService from "/src/services/login.js";
const App = () => {
  _s();
  const [blogs, setBlogs] = useState([]);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [user, setUser] = useState(null);
  const [message, setMessage] = useState("");
  const togglableRef = useRef();
  useEffect(() => {
    const userJSON = localStorage.getItem("loggedUser");
    if (userJSON) {
      const user2 = JSON.parse(userJSON);
      setUser(user2);
      blogService.setToken(user2.token);
    }
  }, []);
  useEffect(() => {
    if (user) {
      blogService.getAll().then((blogs2) => {
        setBlogs(sortBlogsByLikes(blogs2));
      });
    }
  }, [user]);
  const sortBlogsByLikes = (blogs2) => blogs2.sort((a, b) => b.likes - a.likes);
  const handleLogin = async (event) => {
    event.preventDefault();
    try {
      const user2 = await loginService.login({
        username,
        password
      });
      console.log("Logging in with", username, password);
      blogService.setToken(user2.token);
      localStorage.setItem("loggedUser", JSON.stringify(user2));
      setUser(user2);
      setUsername("");
      setPassword("");
    } catch (exception) {
      console.log("Invalid username or password");
      setMessage("Invalid username or password");
      setTimeout(() => {
        setMessage("");
      }, 6e3);
    }
  };
  const handleLogout = () => {
    localStorage.removeItem("loggedUser");
    setUser(null);
  };
  const createBlog = async (newBlog) => {
    try {
      const createdBlog = await blogService.createBlog({
        title: newBlog.title,
        author: newBlog.author,
        url: newBlog.url
      });
      setBlogs(blogs.concat(createdBlog));
      togglableRef.current.toggleVisibility();
      setMessage(`New blog "${createdBlog.title}" by ${createdBlog.author} added`);
      setTimeout(() => {
        setMessage("");
      }, 6e3);
    } catch (exception) {
      console.log("Error when creating new blog");
    }
  };
  const updateBlog = async (modifiedBlog) => {
    try {
      const updatedBlog = await blogService.updateBlog(modifiedBlog);
      const filteredBlogs = blogs.filter((blog) => blog.id !== modifiedBlog.id);
      setBlogs(sortBlogsByLikes(filteredBlogs.concat(modifiedBlog)));
    } catch (exception) {
      console.log("Error when updating the blog");
    }
  };
  const deleteBlog = async (blogToDelete) => {
    try {
      await blogService.deleteBlog(blogToDelete);
      const filteredBlogs = blogs.filter((blog) => blog.id !== blogToDelete.id);
      setBlogs(sortBlogsByLikes(filteredBlogs));
    } catch (exception) {
      console.log("Error when deleting the blog");
    }
  };
  const loginForm = () => /* @__PURE__ */ jsxDEV("form", { onSubmit: handleLogin, children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Log in to application" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 94,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message, color: "red" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 95,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: "Username " }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 97,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { "data-testid": "username", type: "text", value: username, onChange: ({
        target
      }) => setUsername(target.value), name: "username" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 98,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 96,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      /* @__PURE__ */ jsxDEV("span", { children: "Password " }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 103,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("input", { "data-testid": "password", type: "password", value: password, onChange: ({
        target
      }) => setPassword(target.value), name: "password" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 104,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 102,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 108,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { "data-testid": "submitButton", type: "submit", children: "Login" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 109,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 93,
    columnNumber: 27
  }, this);
  const blogsList = () => /* @__PURE__ */ jsxDEV("div", { children: [
    /* @__PURE__ */ jsxDEV("h2", { children: "Blogs" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 112,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: [
      user.name,
      " is logged in  ",
      /* @__PURE__ */ jsxDEV("button", { onClick: handleLogout, children: "Logout" }, void 0, false, {
        fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
        lineNumber: 114,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 113,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 115,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { children: blogs.map((blog) => /* @__PURE__ */ jsxDEV(Blog, { blog, updateBlog, deleteBlog }, blog.id, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 117,
      columnNumber: 28
    }, this)) }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 116,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 111,
    columnNumber: 27
  }, this);
  const loggedUserContent = () => /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV(Togglable, { buttonLabel: "Add blog", ref: togglableRef, children: /* @__PURE__ */ jsxDEV(AddBlogForm, { createBlog, togglableRef }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 122,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 121,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Notification, { message, color: "green" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 124,
      columnNumber: 7
    }, this),
    blogsList()
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 120,
    columnNumber: 35
  }, this);
  return /* @__PURE__ */ jsxDEV(Fragment, { children: [
    /* @__PURE__ */ jsxDEV("h1", { children: "Bloglist app" }, void 0, false, {
      fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
      lineNumber: 128,
      columnNumber: 7
    }, this),
    user ? loggedUserContent() : loginForm()
  ] }, void 0, true, {
    fileName: "/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx",
    lineNumber: 127,
    columnNumber: 10
  }, this);
};
_s(App, "qp2PNB1xyqY9CDCako70TaheT1U=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/dario/Desktop/Dario/Ingenieria/Informática y supercomputacion - Matlab Mathematica/Repositorios Git/FullStackOpen/part4/bloglist-frontend/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUdNLFNBOEJGLFVBOUJFOzs7Ozs7Ozs7Ozs7Ozs7OztBQXZHTixTQUFTQSxVQUFVQyxXQUFXQyxjQUFjO0FBQzVDLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGtCQUFrQjtBQUN6QixPQUFPQyxlQUFlO0FBQ3RCLE9BQU9DLGlCQUFpQjtBQUN4QixPQUFPQyxrQkFBa0I7QUFFekIsTUFBTUMsTUFBTUEsTUFBTTtBQUFBQyxLQUFBO0FBQ2hCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJWixTQUFTLEVBQUU7QUFDckMsUUFBTSxDQUFDYSxVQUFVQyxXQUFXLElBQUlkLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNlLFVBQVVDLFdBQVcsSUFBSWhCLFNBQVMsRUFBRTtBQUMzQyxRQUFNLENBQUNpQixNQUFNQyxPQUFPLElBQUlsQixTQUFTLElBQUk7QUFFckMsUUFBTSxDQUFDbUIsU0FBU0MsVUFBVSxJQUFJcEIsU0FBUyxFQUFFO0FBRXpDLFFBQU1xQixlQUFlbkIsT0FBTztBQUU1QkQsWUFBVSxNQUFNO0FBQ2QsVUFBTXFCLFdBQVdDLGFBQWFDLFFBQVEsWUFBWTtBQUVsRCxRQUFJRixVQUFVO0FBQ1osWUFBTUwsUUFBT1EsS0FBS0MsTUFBTUosUUFBUTtBQUNoQ0osY0FBUUQsS0FBSTtBQUNaVixrQkFBWW9CLFNBQVNWLE1BQUtXLEtBQUs7QUFBQSxJQUNqQztBQUFBLEVBQ0YsR0FBRyxFQUFFO0FBRUwzQixZQUFVLE1BQU07QUFDZCxRQUFJZ0IsTUFBTTtBQUNSVixrQkFBWXNCLE9BQU8sRUFBRUMsS0FBS25CLFlBQVM7QUFDakNDLGlCQUFTbUIsaUJBQWlCcEIsTUFBSyxDQUFDO0FBQUEsTUFDbEMsQ0FBQztBQUFBLElBQ0g7QUFBQSxFQUNGLEdBQUcsQ0FBQ00sSUFBSSxDQUFDO0FBRVQsUUFBTWMsbUJBQW1CcEIsWUFBU0EsT0FBTXFCLEtBQUssQ0FBQ0MsR0FBR0MsTUFBTUEsRUFBRUMsUUFBUUYsRUFBRUUsS0FBSztBQUV4RSxRQUFNQyxjQUFjLE9BQU9DLFVBQVU7QUFDbkNBLFVBQU1DLGVBQWU7QUFFckIsUUFBSTtBQUNGLFlBQU1yQixRQUFPLE1BQU1ULGFBQWErQixNQUFNO0FBQUEsUUFBRTFCO0FBQUFBLFFBQVVFO0FBQUFBLE1BQVMsQ0FBQztBQUU1RHlCLGNBQVFDLElBQUksbUJBQW1CNUIsVUFBVUUsUUFBUTtBQUNqRFIsa0JBQVlvQixTQUFTVixNQUFLVyxLQUFLO0FBQy9CTCxtQkFBYW1CLFFBQVEsY0FBY2pCLEtBQUtrQixVQUFVMUIsS0FBSSxDQUFDO0FBQ3ZEQyxjQUFRRCxLQUFJO0FBQ1pILGtCQUFZLEVBQUU7QUFDZEUsa0JBQVksRUFBRTtBQUFBLElBQ2hCLFNBQVE0QixXQUFXO0FBQ2pCSixjQUFRQyxJQUFJLDhCQUE4QjtBQUUxQ3JCLGlCQUFXLDhCQUE4QjtBQUN6Q3lCLGlCQUFXLE1BQU07QUFDZnpCLG1CQUFXLEVBQUU7QUFBQSxNQUNmLEdBQUcsR0FBSTtBQUFBLElBQ1Q7QUFBQSxFQUNGO0FBRUEsUUFBTTBCLGVBQWVBLE1BQU07QUFDekJ2QixpQkFBYXdCLFdBQVcsWUFBWTtBQUNwQzdCLFlBQVEsSUFBSTtBQUFBLEVBQ2Q7QUFFQSxRQUFNOEIsYUFBYSxPQUFPQyxZQUFZO0FBQ3BDLFFBQUk7QUFDRixZQUFNQyxjQUFjLE1BQU0zQyxZQUFZeUMsV0FBVztBQUFBLFFBQUVHLE9BQU9GLFFBQVFFO0FBQUFBLFFBQU9DLFFBQVFILFFBQVFHO0FBQUFBLFFBQVFDLEtBQUtKLFFBQVFJO0FBQUFBLE1BQUksQ0FBQztBQUNuSHpDLGVBQVNELE1BQU0yQyxPQUFPSixXQUFXLENBQUM7QUFFbEM3QixtQkFBYWtDLFFBQVFDLGlCQUFpQjtBQUV0Q3BDLGlCQUFZLGFBQVk4QixZQUFZQyxLQUFNLFFBQU9ELFlBQVlFLE1BQU8sUUFBTztBQUMzRVAsaUJBQVcsTUFBTTtBQUNmekIsbUJBQVcsRUFBRTtBQUFBLE1BQ2YsR0FBRyxHQUFJO0FBQUEsSUFDVCxTQUFTd0IsV0FBVztBQUNsQkosY0FBUUMsSUFBSSw4QkFBOEI7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFFQSxRQUFNZ0IsYUFBYSxPQUFNQyxpQkFBZ0I7QUFDdkMsUUFBSTtBQUNGLFlBQU1DLGNBQWMsTUFBTXBELFlBQVlrRCxXQUFXQyxZQUFZO0FBQzdELFlBQU1FLGdCQUFnQmpELE1BQU1rRCxPQUFPQyxVQUFRQSxLQUFLQyxPQUFPTCxhQUFhSyxFQUFFO0FBQ3RFbkQsZUFBU21CLGlCQUFpQjZCLGNBQWNOLE9BQU9JLFlBQVksQ0FBQyxDQUFDO0FBQUEsSUFDL0QsU0FBU2QsV0FBVztBQUNsQkosY0FBUUMsSUFBSSw4QkFBOEI7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFFQSxRQUFNdUIsYUFBYSxPQUFNQyxpQkFBZ0I7QUFDdkMsUUFBSTtBQUNGLFlBQU0xRCxZQUFZeUQsV0FBV0MsWUFBWTtBQUN6QyxZQUFNTCxnQkFBZ0JqRCxNQUFNa0QsT0FBT0MsVUFBUUEsS0FBS0MsT0FBT0UsYUFBYUYsRUFBRTtBQUN0RW5ELGVBQVNtQixpQkFBaUI2QixhQUFhLENBQUM7QUFBQSxJQUMxQyxTQUFTaEIsV0FBVztBQUNsQkosY0FBUUMsSUFBSSw4QkFBOEI7QUFBQSxJQUM1QztBQUFBLEVBQ0Y7QUFFQSxRQUFNeUIsWUFBWUEsTUFDaEIsdUJBQUMsVUFBSyxVQUFVOUIsYUFDZDtBQUFBLDJCQUFDLFFBQUcscUNBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QjtBQUFBLElBQ3pCLHVCQUFDLGdCQUFhLFNBQWtCLE9BQU8sU0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE2QztBQUFBLElBQzdDLHVCQUFDLFNBQ0M7QUFBQSw2QkFBQyxVQUFLLHlCQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZTtBQUFBLE1BQ2YsdUJBQUMsV0FBTSxlQUFZLFlBQVcsTUFBSyxRQUFPLE9BQU92QixVQUFVLFVBQVUsQ0FBQztBQUFBLFFBQUVzRDtBQUFBQSxNQUFPLE1BQU1yRCxZQUFZcUQsT0FBT0MsS0FBSyxHQUFHLE1BQUssY0FBckg7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUErSDtBQUFBLFNBRmpJO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsU0FDQztBQUFBLDZCQUFDLFVBQUsseUJBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFDZix1QkFBQyxXQUFNLGVBQVksWUFBVyxNQUFLLFlBQVcsT0FBT3JELFVBQVUsVUFBVSxDQUFDO0FBQUEsUUFBRW9EO0FBQUFBLE1BQU8sTUFBTW5ELFlBQVltRCxPQUFPQyxLQUFLLEdBQUcsTUFBSyxjQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQW1JO0FBQUEsU0FGckk7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUdBO0FBQUEsSUFDQSx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBRztBQUFBLElBQ0gsdUJBQUMsWUFBTyxlQUFZLGdCQUFlLE1BQUssVUFBUyxxQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFzRDtBQUFBLE9BWnhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FhQTtBQUdGLFFBQU1DLFlBQVlBLE1BQ2hCLHVCQUFDLFNBQ0M7QUFBQSwyQkFBQyxRQUFHLHFCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBUztBQUFBLElBQ1QsdUJBQUMsU0FBS3BEO0FBQUFBLFdBQUtxRDtBQUFBQSxNQUFLO0FBQUEsTUFDUix1QkFBQyxZQUFPLFNBQVN4QixjQUFjLHNCQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFDO0FBQUEsU0FEN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUNzRDtBQUFBLElBQ3RELHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFHO0FBQUEsSUFDSCx1QkFBQyxTQUNFbkMsZ0JBQU00RCxJQUFJVCxVQUNULHVCQUFDLFFBQW1CLE1BQVksWUFBd0IsY0FBN0NBLEtBQUtDLElBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBK0UsQ0FDakYsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxPQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVQTtBQUdGLFFBQU1TLG9CQUFvQkEsTUFDeEIsbUNBQ0U7QUFBQSwyQkFBQyxhQUFVLGFBQVksWUFBVyxLQUFLbkQsY0FDckMsaUNBQUMsZUFBWSxZQUF3QixnQkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnRSxLQURsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLGdCQUFhLFNBQWtCLE9BQU8sV0FBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUErQztBQUFBLElBQzlDZ0QsVUFBVTtBQUFBLE9BTGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBR0YsU0FDRSxtQ0FDRTtBQUFBLDJCQUFDLFFBQUcsNEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFnQjtBQUFBLElBQ2ZwRCxPQUNHdUQsa0JBQWtCLElBQ2xCTixVQUFVO0FBQUEsT0FKaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBRUo7QUFBQ3hELEdBL0lLRCxLQUFHO0FBQUFnRSxLQUFIaEU7QUFpSk4sZUFBZUE7QUFBRyxJQUFBZ0U7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlUmVmIiwiQWRkQmxvZ0Zvcm0iLCJCbG9nIiwiTm90aWZpY2F0aW9uIiwiVG9nZ2xhYmxlIiwiYmxvZ1NlcnZpY2UiLCJsb2dpblNlcnZpY2UiLCJBcHAiLCJfcyIsImJsb2dzIiwic2V0QmxvZ3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwicGFzc3dvcmQiLCJzZXRQYXNzd29yZCIsInVzZXIiLCJzZXRVc2VyIiwibWVzc2FnZSIsInNldE1lc3NhZ2UiLCJ0b2dnbGFibGVSZWYiLCJ1c2VySlNPTiIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJzZXRUb2tlbiIsInRva2VuIiwiZ2V0QWxsIiwidGhlbiIsInNvcnRCbG9nc0J5TGlrZXMiLCJzb3J0IiwiYSIsImIiLCJsaWtlcyIsImhhbmRsZUxvZ2luIiwiZXZlbnQiLCJwcmV2ZW50RGVmYXVsdCIsImxvZ2luIiwiY29uc29sZSIsImxvZyIsInNldEl0ZW0iLCJzdHJpbmdpZnkiLCJleGNlcHRpb24iLCJzZXRUaW1lb3V0IiwiaGFuZGxlTG9nb3V0IiwicmVtb3ZlSXRlbSIsImNyZWF0ZUJsb2ciLCJuZXdCbG9nIiwiY3JlYXRlZEJsb2ciLCJ0aXRsZSIsImF1dGhvciIsInVybCIsImNvbmNhdCIsImN1cnJlbnQiLCJ0b2dnbGVWaXNpYmlsaXR5IiwidXBkYXRlQmxvZyIsIm1vZGlmaWVkQmxvZyIsInVwZGF0ZWRCbG9nIiwiZmlsdGVyZWRCbG9ncyIsImZpbHRlciIsImJsb2ciLCJpZCIsImRlbGV0ZUJsb2ciLCJibG9nVG9EZWxldGUiLCJsb2dpbkZvcm0iLCJ0YXJnZXQiLCJ2YWx1ZSIsImJsb2dzTGlzdCIsIm5hbWUiLCJtYXAiLCJsb2dnZWRVc2VyQ29udGVudCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSwgdXNlRWZmZWN0LCB1c2VSZWYgfSBmcm9tICdyZWFjdCdcbmltcG9ydCBBZGRCbG9nRm9ybSBmcm9tICcuL2NvbXBvbmVudHMvQWRkQmxvZ0Zvcm0nXG5pbXBvcnQgQmxvZyBmcm9tICcuL2NvbXBvbmVudHMvQmxvZydcbmltcG9ydCBOb3RpZmljYXRpb24gZnJvbSAnLi9jb21wb25lbnRzL05vdGlmaWNhdGlvbidcbmltcG9ydCBUb2dnbGFibGUgZnJvbSAnLi9jb21wb25lbnRzL1RvZ2dsYWJsZSdcbmltcG9ydCBibG9nU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2Jsb2dzJ1xuaW1wb3J0IGxvZ2luU2VydmljZSBmcm9tICcuL3NlcnZpY2VzL2xvZ2luJ1xuXG5jb25zdCBBcHAgPSAoKSA9PiB7XG4gIGNvbnN0IFtibG9ncywgc2V0QmxvZ3NdID0gdXNlU3RhdGUoW10pXG4gIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFtwYXNzd29yZCwgc2V0UGFzc3dvcmRdID0gdXNlU3RhdGUoJycpXG4gIGNvbnN0IFt1c2VyLCBzZXRVc2VyXSA9IHVzZVN0YXRlKG51bGwpXG5cbiAgY29uc3QgW21lc3NhZ2UsIHNldE1lc3NhZ2VdID0gdXNlU3RhdGUoJycpXG5cbiAgY29uc3QgdG9nZ2xhYmxlUmVmID0gdXNlUmVmKClcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGNvbnN0IHVzZXJKU09OID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oJ2xvZ2dlZFVzZXInKVxuXG4gICAgaWYgKHVzZXJKU09OKSB7XG4gICAgICBjb25zdCB1c2VyID0gSlNPTi5wYXJzZSh1c2VySlNPTilcbiAgICAgIHNldFVzZXIodXNlcilcbiAgICAgIGJsb2dTZXJ2aWNlLnNldFRva2VuKHVzZXIudG9rZW4pXG4gICAgfVxuICB9LCBbXSlcblxuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmICh1c2VyKSB7XG4gICAgICBibG9nU2VydmljZS5nZXRBbGwoKS50aGVuKGJsb2dzID0+IHtcbiAgICAgICAgc2V0QmxvZ3Moc29ydEJsb2dzQnlMaWtlcyhibG9ncykpXG4gICAgICB9KVxuICAgIH1cbiAgfSwgW3VzZXJdKVxuXG4gIGNvbnN0IHNvcnRCbG9nc0J5TGlrZXMgPSBibG9ncyA9PiBibG9ncy5zb3J0KChhLCBiKSA9PiBiLmxpa2VzIC0gYS5saWtlcylcblxuICBjb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jIChldmVudCkgPT4ge1xuICAgIGV2ZW50LnByZXZlbnREZWZhdWx0KClcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCB1c2VyID0gYXdhaXQgbG9naW5TZXJ2aWNlLmxvZ2luKHsgdXNlcm5hbWUsIHBhc3N3b3JkIH0pXG5cbiAgICAgIGNvbnNvbGUubG9nKCdMb2dnaW5nIGluIHdpdGgnLCB1c2VybmFtZSwgcGFzc3dvcmQpXG4gICAgICBibG9nU2VydmljZS5zZXRUb2tlbih1c2VyLnRva2VuKVxuICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oJ2xvZ2dlZFVzZXInLCBKU09OLnN0cmluZ2lmeSh1c2VyKSlcbiAgICAgIHNldFVzZXIodXNlcilcbiAgICAgIHNldFVzZXJuYW1lKCcnKVxuICAgICAgc2V0UGFzc3dvcmQoJycpXG4gICAgfSBjYXRjaChleGNlcHRpb24pIHtcbiAgICAgIGNvbnNvbGUubG9nKCdJbnZhbGlkIHVzZXJuYW1lIG9yIHBhc3N3b3JkJylcblxuICAgICAgc2V0TWVzc2FnZSgnSW52YWxpZCB1c2VybmFtZSBvciBwYXNzd29yZCcpXG4gICAgICBzZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgc2V0TWVzc2FnZSgnJylcbiAgICAgIH0sIDYwMDApXG4gICAgfVxuICB9XG5cbiAgY29uc3QgaGFuZGxlTG9nb3V0ID0gKCkgPT4ge1xuICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKCdsb2dnZWRVc2VyJylcbiAgICBzZXRVc2VyKG51bGwpXG4gIH1cblxuICBjb25zdCBjcmVhdGVCbG9nID0gYXN5bmMgKG5ld0Jsb2cpID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgY3JlYXRlZEJsb2cgPSBhd2FpdCBibG9nU2VydmljZS5jcmVhdGVCbG9nKHsgdGl0bGU6IG5ld0Jsb2cudGl0bGUsIGF1dGhvcjogbmV3QmxvZy5hdXRob3IsIHVybDogbmV3QmxvZy51cmwgfSlcbiAgICAgIHNldEJsb2dzKGJsb2dzLmNvbmNhdChjcmVhdGVkQmxvZykpXG5cbiAgICAgIHRvZ2dsYWJsZVJlZi5jdXJyZW50LnRvZ2dsZVZpc2liaWxpdHkoKVxuXG4gICAgICBzZXRNZXNzYWdlKGBOZXcgYmxvZyBcIiR7Y3JlYXRlZEJsb2cudGl0bGV9XCIgYnkgJHtjcmVhdGVkQmxvZy5hdXRob3J9IGFkZGVkYClcbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBzZXRNZXNzYWdlKCcnKVxuICAgICAgfSwgNjAwMClcbiAgICB9IGNhdGNoIChleGNlcHRpb24pIHtcbiAgICAgIGNvbnNvbGUubG9nKCdFcnJvciB3aGVuIGNyZWF0aW5nIG5ldyBibG9nJylcbiAgICB9XG4gIH1cblxuICBjb25zdCB1cGRhdGVCbG9nID0gYXN5bmMgbW9kaWZpZWRCbG9nID0+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdXBkYXRlZEJsb2cgPSBhd2FpdCBibG9nU2VydmljZS51cGRhdGVCbG9nKG1vZGlmaWVkQmxvZylcbiAgICAgIGNvbnN0IGZpbHRlcmVkQmxvZ3MgPSBibG9ncy5maWx0ZXIoYmxvZyA9PiBibG9nLmlkICE9PSBtb2RpZmllZEJsb2cuaWQpXG4gICAgICBzZXRCbG9ncyhzb3J0QmxvZ3NCeUxpa2VzKGZpbHRlcmVkQmxvZ3MuY29uY2F0KG1vZGlmaWVkQmxvZykpKVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgY29uc29sZS5sb2coJ0Vycm9yIHdoZW4gdXBkYXRpbmcgdGhlIGJsb2cnKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGRlbGV0ZUJsb2cgPSBhc3luYyBibG9nVG9EZWxldGUgPT4ge1xuICAgIHRyeSB7XG4gICAgICBhd2FpdCBibG9nU2VydmljZS5kZWxldGVCbG9nKGJsb2dUb0RlbGV0ZSlcbiAgICAgIGNvbnN0IGZpbHRlcmVkQmxvZ3MgPSBibG9ncy5maWx0ZXIoYmxvZyA9PiBibG9nLmlkICE9PSBibG9nVG9EZWxldGUuaWQpXG4gICAgICBzZXRCbG9ncyhzb3J0QmxvZ3NCeUxpa2VzKGZpbHRlcmVkQmxvZ3MpKVxuICAgIH0gY2F0Y2ggKGV4Y2VwdGlvbikge1xuICAgICAgY29uc29sZS5sb2coJ0Vycm9yIHdoZW4gZGVsZXRpbmcgdGhlIGJsb2cnKVxuICAgIH1cbiAgfVxuXG4gIGNvbnN0IGxvZ2luRm9ybSA9ICgpID0+IChcbiAgICA8Zm9ybSBvblN1Ym1pdD17aGFuZGxlTG9naW59PlxuICAgICAgPGgyPkxvZyBpbiB0byBhcHBsaWNhdGlvbjwvaDI+XG4gICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e21lc3NhZ2V9IGNvbG9yPXsncmVkJ30vPlxuICAgICAgPGRpdj5cbiAgICAgICAgPHNwYW4+VXNlcm5hbWUgPC9zcGFuPlxuICAgICAgICA8aW5wdXQgZGF0YS10ZXN0aWQ9J3VzZXJuYW1lJyB0eXBlPSd0ZXh0JyB2YWx1ZT17dXNlcm5hbWV9IG9uQ2hhbmdlPXsoeyB0YXJnZXQgfSkgPT4gc2V0VXNlcm5hbWUodGFyZ2V0LnZhbHVlKX0gbmFtZT0ndXNlcm5hbWUnLz5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdj5cbiAgICAgICAgPHNwYW4+UGFzc3dvcmQgPC9zcGFuPlxuICAgICAgICA8aW5wdXQgZGF0YS10ZXN0aWQ9J3Bhc3N3b3JkJyB0eXBlPSdwYXNzd29yZCcgdmFsdWU9e3Bhc3N3b3JkfSBvbkNoYW5nZT17KHsgdGFyZ2V0IH0pID0+IHNldFBhc3N3b3JkKHRhcmdldC52YWx1ZSl9IG5hbWU9J3Bhc3N3b3JkJy8+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxici8+XG4gICAgICA8YnV0dG9uIGRhdGEtdGVzdGlkPSdzdWJtaXRCdXR0b24nIHR5cGU9J3N1Ym1pdCc+TG9naW48L2J1dHRvbj5cbiAgICA8L2Zvcm0+XG4gIClcblxuICBjb25zdCBibG9nc0xpc3QgPSAoKSA9PiAoXG4gICAgPGRpdj5cbiAgICAgIDxoMj5CbG9nczwvaDI+XG4gICAgICA8ZGl2Pnt1c2VyLm5hbWV9IGlzIGxvZ2dlZCBpblxuICAgICAgICAmbmJzcDs8YnV0dG9uIG9uQ2xpY2s9e2hhbmRsZUxvZ291dH0+TG9nb3V0PC9idXR0b24+PC9kaXY+XG4gICAgICA8YnIvPlxuICAgICAgPGRpdj5cbiAgICAgICAge2Jsb2dzLm1hcChibG9nID0+XG4gICAgICAgICAgPEJsb2cga2V5PXtibG9nLmlkfSBibG9nPXtibG9nfSB1cGRhdGVCbG9nPXt1cGRhdGVCbG9nfSBkZWxldGVCbG9nPXtkZWxldGVCbG9nfS8+XG4gICAgICAgICl9XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKVxuXG4gIGNvbnN0IGxvZ2dlZFVzZXJDb250ZW50ID0gKCkgPT4gKFxuICAgIDw+XG4gICAgICA8VG9nZ2xhYmxlIGJ1dHRvbkxhYmVsPVwiQWRkIGJsb2dcIiByZWY9e3RvZ2dsYWJsZVJlZn0+XG4gICAgICAgIDxBZGRCbG9nRm9ybSBjcmVhdGVCbG9nPXtjcmVhdGVCbG9nfSB0b2dnbGFibGVSZWY9e3RvZ2dsYWJsZVJlZn0vPlxuICAgICAgPC9Ub2dnbGFibGU+XG4gICAgICA8Tm90aWZpY2F0aW9uIG1lc3NhZ2U9e21lc3NhZ2V9IGNvbG9yPXsnZ3JlZW4nfS8+XG4gICAgICB7YmxvZ3NMaXN0KCl9XG4gICAgPC8+XG4gIClcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8aDE+QmxvZ2xpc3QgYXBwPC9oMT5cbiAgICAgIHt1c2VyXG4gICAgICAgID8gbG9nZ2VkVXNlckNvbnRlbnQoKVxuICAgICAgICA6IGxvZ2luRm9ybSgpXG4gICAgICB9XG4gICAgPC8+XG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwIl0sImZpbGUiOiIvVXNlcnMvZGFyaW8vRGVza3RvcC9EYXJpby9JbmdlbmllcmlhL0luZm9ybWHMgXRpY2EgeSBzdXBlcmNvbXB1dGFjaW9uIC0gTWF0bGFiIE1hdGhlbWF0aWNhL1JlcG9zaXRvcmlvcyBHaXQvRnVsbFN0YWNrT3Blbi9wYXJ0NC9ibG9nbGlzdC1mcm9udGVuZC9zcmMvQXBwLmpzeCJ9